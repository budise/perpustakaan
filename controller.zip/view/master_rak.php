<section class="content-header">
	<h1>
		Master Rak
		<small>Daftar Rak</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-th"></i> Dashboard</a></li>
		<li class="active">Master Rak</li>
	</ol>
</section>

<section class="content">
	<div class="box box-widget">
		<div class="box-header with-border">
			<h6 class="box-title">Master Rak</h6>
			<div class="box-tools pull-right">				
				<button type="button" class="btn btn-box-tool" onclick="addNew();"><i class="fa fa-plus fa-fw"></i> Tambah</button>
			</div>
		</div>

		<div class="box-body">
			<div class="table-responsive">
				<table class="table table-responsive table-bordered table-hover dataGrid" id="dataGrid">
					<thead>
						<tr>
							<th style="text-align:center">Kode</th>
							<th>Keterangan</th>
							<th>Alamat</th>
							<th style="text-align:center">Jenis</th>
							<th style="text-align: center;width:10%;"><i class="fa fa-gears fa-fw"></i></th>
						</tr>
					</thead>

					<tbody>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>

<div class="modal fade" id="modalForm">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times fa-fw"></i></button>
				<h5 class="modal-title" id="modalTitle"></h5>
			</div>

			<div class="modal-body">
				<input type="hidden" id="txtId" value="0">

				<div class="row">
					<div class="col-md-6">
						<label class="small-label">Nama Lokasi</label>
						<input type="text" class="form-control input-sm" id="txtNamaLokasi">
					</div>

					<div class="col-md-6">
						<label class="small-label">Jenis</label>
						<select class="form-control input-sm" id="txtJenisLokasi"></select>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12">
						<label class="small-label">Alamat</label>
						<textarea class="form-control" rows="3" style="resize: none;" id="txtAlamat"></textarea>
					</div>
				</div>

			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-sm" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Tutup</button>
				<button type="button" class="btn btn-success btn-sm" onclick="save();"><i class="fa fa-check fa-fw"></i> Simpan</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">


	var tabel = $("#dataGrid").DataTable({
		processing: true,
		serverSide: true,
		paging: true,
		"ajax": {
			url: "controller/master_rak.php",
			type: "post",
			data: {
				act: "getAll",
			}
		},
		columns: [
		{
			className: "centerCol",
			width: "10%",
			data: "kode_lokasi"
		},
		{data: "keterangan_lokasi"},
		{data: "alamat_lokasi"},
		{
			className: "centerCol",
			width: "10%",
			data: "jenis_lokasi",
			render: function(data, type, row){
				return "<label class='label label-success'><i class='fa fa-map-marker fa-fw'></i> "+data+"</label>";
			}
		},
		{
			data: null,
			className: "centerCol",
			sortable: false,
			defaultContent: "<button type='button' class='btn btn-info btn-xs btnEdit'><i class='fa fa-pencil fa-fw'></i></button> <button type='button' class='btn btn-danger btn-xs btnDel'><i class='fa fa-trash fa-fw'></i></button>"
		}
		]
	});

	$("#dataGrid tbody").on("click", ".btnEdit", function(){
		var data = tabel.row($(this).parents("tr")).data();
		edit(data[0]);
	});

	$("#dataGrid tbody").on("click", ".btnDel", function(){
		var data = tabel.row($(this).parents("tr")).data();
		del(data[0]);
	});

	function resetField(){
		$("#txtId").val("0");
		$("#modalForm .form-control").val("");
		$("#txtNamaLokasi").focus();
		getJenisLokasi();
	}

	function addNew(){
		resetField();

		$("#modalTitle").html("<i class='fa fa-plus fa-fw'></i> Tambah Lokasi Baru");

		$("#modalForm").modal({
			backdrop: "static"
		});
	}


	function getJenisLokasi(){
		$.post("controller/master_rak.php",{
			act: "get_jenis_lokasi"
		}, function(data){

			var lst = "";

			$(data.jenis_lokasi).each(function(i, val){
				lst += "<option value='"+val+"' "+(i === 0 ? "selected" : "")+">"+val+"</option>";
			});

			$("#txtJenisLokasi").html(lst);

		}, "json");
	}

	getJenisLokasi();

	function edit(id){
		resetField();

		$.post("controller/master_rak.php",{
			act: "getData",
			id: id
		}, function(data){
			var dataSet = data.result[0];

			$("#txtId").val(dataSet.id_lokasi);
			$("#txtNamaLokasi").val(dataSet.keterangan_lokasi);
			$("#txtJenisLokasi").val(dataSet.jenis_lokasi);
			$("#txtAlamat").val(dataSet.alamat_lokasi);

			$("#modalTitle").html("<i class='fa fa-pencil fa-fw'></i> Edit Lokasi");

			$("#modalForm").modal({
				backdrop: "static"
			});

		}, "json");
	}

	function del(id){
		var konfirmasi = confirm("Apakah yakin akan menghapus data ini ?");

		if(konfirmasi){
			$.post("controller/master_rak.php",{
				act: "del",
				id: id
			}, function(data){
				if(data.status === true){
					tabel.ajax.reload();
				}else{
					alert("Data gagal di hapus");
				}

			}, "json");
		}
	}

	function save(){
		var id = $("#txtId").val();
		var nama = $("#txtNamaLokasi").val();
		var jenis_lokasi = $("#txtJenisLokasi").val();
		var alamat = $("#txtAlamat").val();

		$.post("controller/master_rak.php",{
			act: "save",
			id: id,
			keterangan_lokasi: nama,
			jenis_lokasi: jenis_lokasi,
			alamat_lokasi: alamat
		}, function(data){

			if(data.status === true){
				$("#modalForm").modal("hide");
				tabel.ajax.reload();
			}else{
				alert("Data gagal di simpan");
			}

		}, "json");

	}

</script>