<?php
$global_name = $_GET['pg'];
?>
<style type="text/css">
    .select2-container--default .select2-selection--single{
        height: 30px !important;
    }

    .select2-container--default .select2-selection--multiple{
        border-radius: 0px !important;
    }

    .select2-container--default .select2-selection--multiple .select2-selection__choice{
        background-color: #27AE60 !important;
    }

    .select2-container--default .select2-selection--multiple .select2-selection__choice__remove{
        color: #fff !important;
    }

    .datepicker{
        z-index: 1151 !important;
    }
</style>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <i class="fa fa-user"></i> Laporan Pengembalian
        <small>Cetak Data Pengembalian</small>
    </h1>
</section>

<!-- Main content -->
<section class="content container-fluid">
    <div class="box box-solid box-primary">
        <div class="box-header with-border">
            <h4 class="box-title">Filter Cetak Laporan Pengembalian</h4>
        </div>

        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-primary ">
                        <div class="box-header with-border">
                            <h4 class="box-title"><i class="fa fa-filter"></i> Filter Kriteria</h4>
                        </div>

                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-calendar"></i> Dari Tanggal
                                            </span>

                                            <input type="text" class="form-control input-sm tanggal" id="txtStartDate" value="yyyy-mm-dd"> 
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-calendar"></i> Sampai Tanggal
                                            </span>

                                            <input type="text" class="form-control input-sm tanggal" id="txtEndDate" value="yyyy-mm-dd"> 
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-user"></i> Anggota
                                        </span>

                                        <select class="form-control input-sm select2" id="txtIdAnggota">
                                            <option value="0">- Pilih Anggota -</option>
                                            <?php
                                            $getAnggota = $db->query("SELECT * FROM anggota");
                                            foreach ($getAnggota->fetchAll() as $key => $val) {
                                                ?>
                                                <option value="<?= $val['id']; ?>">[<?= $val['kd_anggota']; ?>] <?= $val['nama']; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-tags"></i> Status
                                        </span>

                                        <select class="form-control input-sm select2" id="txtIdAnggota">
                                            <option value="0">- Pilih Status -</option>
                                            <?php
                                            $getAnggota = $db->query("SELECT * FROM anggota");
                                            foreach ($getAnggota->fetchAll() as $key => $val) {
                                                ?>
                                                <option value="<?= $val['id']; ?>">[<?= $val['kd_anggota']; ?>] <?= $val['nama']; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <button type="button" class="btn btn-success btn-sm" onclick="cetakSemuaData();"><i class="fa fa-print"></i> Cetak Pengembalian</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- /.content -->

<script type="text/javascript">
    function cetakSemuaData() {
        var startDate = $("#txtStartDate").val();
        var endDate = $("#txtEndDate").val();

        // if ($("#txtIdAnggota").val() === "0") {
        //     swal("Info", "Mohon pilih Anggota untuk melihat Laporan Pengembalian", "info");
        // } else {
            window.open("controller/laporan_pengembalian/cetakLaporan.php?act=cetakSemuaData&startDate=" + $("#txtStartDate").val() + "&endDate=" + $("#txtEndDate").val() + "&id_anggota=" + $("#txtIdAnggota").val() + "");
        // }


    }
</script>
