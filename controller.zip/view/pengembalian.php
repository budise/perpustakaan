<style type="text/css">
	.form-control {
		margin-bottom: 10px;
	}
</style>
<section class="content-header">
	<h1>
		Pengembalian
		<small>Pengembalian Pinjaman Buku</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-th"></i> Dashboard</a></li>
		<li class="active">Pengembalian Pinjaman</li>
	</ol>
</section>

<section class="content">
	<div class="box box-widget">
		<div class="box-header with-border">
			<h6 class="box-title">List Pengembalian Pinjaman</h6>
			<div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" onclick="addNew();"><i class="fa fa-plus fa-fw"></i> Tambah</button>
			</div>
		</div>

		<div class="box-body">
			<div class="table-responsive">
				<table class="table table-bordered table-hover dataGrid" id="dataGrid">
					<thead>
						<tr>
							<th style="text-align:center">Kode Pengembalian</th>
							<th style="text-align: center;">Kode Peminjaman</th>
							<th style="text-align:center">Tanggal Pinjam</th>
							<th style="text-align:center">Tanggal Kembali</th>
							<th style="text-align:center">Anggota</th>
							<th style="text-align:center">Denda</th>
							<th>Keterangan</th>
							<th style="width:10%;text-align:center;"><i class="fa fa-gears fa-fw"></i></th>
						</tr>
					</thead>

					<tbody>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>

<div class="modal fade" id="modalForm">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times fa-fw"></i></button>
				<h5 class="modal-title" id="modalTitle"></h5>
			</div>

			<div class="modal-body">
				<input type="hidden" id="act" name="act" value="save">
				<input type="hidden" id="txtId" name="id" value="0">

				<div class="row">
					<div class="col-md-4">
						<table class="small-table">
							<tr>
								<td style="vertical-align: middle;">Anggota<span class="pull-right">:</span></td>
								<td>
									<select class="form-control input-sm select2" id="txtIdPembelian" name="id_pembelian" onchange="getOrder();"></select>
								</td>
							</tr>
							<tr>
								<td style="vertical-align: middle;">Peminjaman <span class="pull-right">:</span></td>
								<td><select class="form-control input-sm select2" id="txtIdLokasi" name="id_lokasi"></select></td>
							</tr>
							<tr>
								<td style="vertical-align: middle;width: 35%;">Tanggal Kembali <span class="pull-right">:</span></td>
								<td><input type="text" class="form-control input-sm tanggal" id="txtTanggal"></td>
							</tr>
						</table>
					</div>
					<div class="col-md-4">
					</div>

					<div class="col-md-4">
						<tr>
							<td style="vertical-align: middle;width: 35%;">Tanggal Kembali Seharusnya <span class="pull-right">:</span></td>
							<td><input type="text" class="form-control input-sm tanggal" id="txtTanggal"></td>
						</tr>
						<tr>
							<td style="vertical-align: middle;width: 35%;">Telat & Denda <span class="pull-right">:</span></td></br>
							<!-- <td><input type="number" class="form-control input-sm tanggal"></td> -->
							<td><label>0 hari</label> <label>Rp.0</label></td></br>
						</tr>

						<label class="small-label">Keterangan</label>
						<textarea class="form-control" rows="2" style="resize:none" id="txtKeterangan" name="keterangan"></textarea>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12">
						<!-- <button type="button" class="btn btn-primary btn-sm btn-flat bg-green" onclick="addDetail()"><i class="fa fa-plus fa-fw"></i> Tambah</button> -->

						<div class="table-responsive" style="margin-top: 1em;">
							<table class="table table-condensed table-bordered table-detail">
								<thead>
									<tr>
										<th>Kode Buku</th>
										<th>Judul Buku</th>
										<th style="text-align: center;width:16%;">Jumlah</th>
										<th style="text-align: center;width:16%;">Keterangan</th>
									</tr>
								</thead>

								<tbody id="detail-table">

								</tbody>

								<tfoot>
									<tr>
										<th style="text-align: right;vertical-align: middle;">Total</th>
										<th style="text-align: center;vertical-align: middle;" id="lblTotal1"></th>
										<th style="text-align: center;vertical-align: middle;" id="lblTotal2"></th>
									</tr>
								</tfoot>
							</table>


						</div>
					</div>
				</div>


			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-sm" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Tutup</button>
				<button type="button" class="btn btn-success btn-sm" onclick="save();"><i class="fa fa-check fa-fw"></i> Simpan</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modalDetail">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times fa-fw"></i></button>
				<h5 class="modal-title"><i class="fa fa-file fa-fw"></i> Detail Penerimaan</h5>
			</div>

			<div class="modal-body">
				<div class="row">
					<div class="col-md-8 col-sm-12 col-xs-12" style="margin-bottom: 10px;">
						<div class="table-responsive" style="margin-top: 5px;">
							<table class="small-table">
								<tr>
									<td style="width: 20%">Kode</td>
									<td>: <span id="lblKode"></span></td>
								</tr>
								<tr>
									<td>Tanggal</td>
									<td>: <span id="lblTanggal"></span></td>
								</tr>
								<tr>
									<td>Lokasi</td>
									<td>: <span id="lblLokasi"></span></td>
								</tr>
								<tr>
									<td>Kode Beli</td>
									<td>: <span id="lblKodeBeli"></span></td>
								</tr>
							</table>
						</div>
					</div>

					<div class="col-md-4 col-sm-12 col-xs-12">
						<label class="small-label">Keterangan</label><br>
						<span id="lblKeterangan"></span>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12">
						<div class="table-responsive">
							<table class="table table-bordered table-detail">
								<thead>
									<tr>
										<th>Barang</th>
										<th style="width:16%;text-align: center;">Jumlah 1</th>
										<th style="width:16%;text-align: center;">Jumlah 2</th>
									</tr>
								</thead>

								<tbody id="detail-box">
								</tbody>
							</table>
						</div>
					</div>
				</div>


			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-sm" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Tutup</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var tabel = $("#dataGrid").DataTable({
		processing: true,
		serverSide: true,
		paging: true,
		order: [
			[0, "desc"]
		],
		"ajax": {
			url: "controller/penerimaan_pembelian.php",
			type: "post",
			data: {
				act: "getAll",
			}
		},
		columns: [{
				className: "centerCol",
				width: "15%",
				data: "kode_penerimaan_pembelian",
				render: function(data) {
					return "<a href='#' class='detail-data'>" + (data === null || data === '' ? '-' : data) + "</a>"
				}
			},
			{
				className: "centerCol",
				width: "15%",
				data: "kode_pembelian"
			},
			{
				className: "centerCol",
				width: "12%",
				data: "tanggalString"
			},
			{
				data: "keterangan_lokasi"
			},
			{
				data: "keterangan",
				sortable: false
			},
			{
				data: null,
				className: "centerCol",
				sortable: false,
				defaultContent: "<button type='button' class='btn btn-info btn-xs btnEdit'><i class='fa fa-pencil fa-fw'></i></button> <button type='button' class='btn btn-danger btn-xs btnDel'><i class='fa fa-trash fa-fw'></i></button>"
			}
		]
	});

	$("#dataGrid tbody").on("click", ".btnEdit", function() {
		var data = tabel.row($(this).parents("tr")).data();
		edit(data[0]);
	});

	$("#dataGrid tbody").on("click", ".btnDel", function() {
		var data = tabel.row($(this).parents("tr")).data();
		del(data[0]);
	});

	$("#dataGrid tbody").on("click", ".detail-data", function() {
		var data = tabel.row($(this).parents("tr")).data();
		detail(data[0]);
	});



	function addDetail() {
		$.ajax({
			type: "post",
			url: "tabel-form/penerimaan_detail.php",
			data: {
				act: "add"
			},
			success: function(data) {
				$("#detail-table").append(data);
				$(".select2").select2();
			}
		});
	}

	function editDetail(id) {
		$.ajax({
			type: "post",
			url: "tabel-form/penerimaan_detail.php",
			data: {
				act: "edit",
				id: id
			},
			success: function(data) {
				$("#detail-table").html(data);
				$(".select2").select2();
				hitungGrandTotal();
			}
		});
	}

	function viewDetail(id) {
		$.ajax({
			type: "post",
			url: "tabel-form/penerimaan_detail.php",
			data: {
				act: "detail",
				id: id
			},
			success: function(data) {
				$("#detail-box").html(data);
			}
		});
	}

	function getOrder() {
		var id = $("#txtIdPembelian").val();

		$.ajax({
			type: "post",
			url: "tabel-form/penerimaan_detail.php",
			data: {
				act: "get_order",
				id: id
			},
			success: function(data) {
				$("#detail-table").html(data);
				hitungGrandTotal();


			}
		});

	}


	$("#detail-table").on("click", ".removeDetail", function() {
		$(this).closest("tr").remove();

		hitungGrandTotal();
	});


	$("#detail-table").on("change", ".jumlah_satuan_diterima", function() {

		var id_detail = $(this).closest("tr").find(".id_detail_pembelian").val();
		var data_field = $(this);


		$.post("controller/penerimaan_pembelian.php", {
			act: "cekJumlah",
			state: 1,
			jumlah: $(this).val(),
			id_detail_pembelian: id_detail
		}, function(data) {

			if (data.status === "max") {
				alert("jumlah maximal : " + data.max);
				data_field.val(data.max);
				data_field.focus();
			}

		}, "json");


		hitungGrandTotal();
	});

	$("#detail-table").on("change", ".jumlah_satuan2_diterima", function() {

		var id_detail = $(this).closest("tr").find(".id_detail_pembelian").val();
		var data_field = $(this);

		$.post("controller/penerimaan_pembelian.php", {
			act: "cekJumlah",
			state: 2,
			jumlah: $(this).val(),
			id_detail_pembelian: id_detail
		}, function(data) {
			if (data.status === "max") {
				alert("jumlah maximal : " + data.max);
				data_field.val(data.max);
				data_field.focus();
			}
		}, "json");


		hitungGrandTotal();
	});



	function hitungGrandTotal() {
		var grandTotal1 = 0;
		var grandTotal2 = 0;

		$(".jumlah_satuan_diterima").each(function(i, val) {
			var jumlah1 = isNaN($(this).val()) ? 0 : $(this).val();
			grandTotal1 = grandTotal1 + eval(jumlah1);
		});
		$("#lblTotal1").html(grandTotal1);

		$(".jumlah_satuan2_diterima").each(function(i, val) {
			var jumlah2 = isNaN($(this).val()) ? 0 : $(this).val();
			grandTotal2 = grandTotal2 + eval(jumlah2);
		});
		$("#lblTotal2").html(grandTotal2);

	}


	function detail(id) {

		$.post("controller/penerimaan_pembelian.php", {
			act: "getData",
			id: id
		}, function(data) {

			var dataSet = data.result[0];

			$("#lblKode").html(dataSet.kode_penerimaan_pembelian);
			$("#lblTanggal").html(dataSet.tanggal);
			$("#lblLokasi").html(dataSet.keterangan_lokasi);
			$("#lblKodeBeli").html(dataSet.kode_pembelian);
			$("#lblKeterangan").html(dataSet.keterangan);

			viewDetail(id);

		}, "json");

		$("#modalDetail").modal({
			backdrop: "static"
		});
	}

	function resetField() {
		$("#txtId").val("0");
		$("#modalForm .form-control").val("");
		$("#txtTanggal").focus();
		$("#txtIdLokasi").val("0").trigger("change");
		$("#lblTotal1, #lblTotal2").html("0");




		$("#detail-table").html("");

	}

	function getLokasi() {
		$.post("controller/penerimaan_pembelian.php", {
			act: "getLokasi"
		}, function(data) {
			var lst = "";

			lst += "<option value='0' selected>- Pilih Lokasi -</option>";

			$(data.result).each(function(i, val) {
				lst += "<option value='" + val.id_lokasi + "'>[" + val.kode_lokasi + "] " + val.keterangan_lokasi + "</option>"
			});

			$("#txtIdLokasi").html(lst);

		}, "json");
	}

	getLokasi();


	function getOrderPembelian() {
		$.post("controller/penerimaan_pembelian.php", {
			act: "getOrder",
		}, function(data) {
			var lst = "";

			lst += "<option value='0'>- Cari Pembelian -</option>";

			$(data.result).each(function(i, val) {

				var jumlah_terima_1 = val.total_penerimaan_1 === null || val.total_penerimaan_1 === "" ? 0 : val.total_penerimaan_1;
				var jumlah_terima_2 = val.total_penerimaan_2 === null || val.total_penerimaan_2 === "" ? 0 : val.total_penerimaan_2;
				var jumlah_beli_1 = val.total_beli_1;
				var jumlah_beli_2 = val.total_beli_2;


				if (jumlah_terima_1 < jumlah_beli_1) {
					lst += "<option value='" + val.id_pembelian + "'>[" + val.kode_pembelian + "] " + val.tanggalString + "</option>";
				}


			});

			$("#txtIdPembelian").html(lst);

		}, "json");
	}

	getOrderPembelian();


	function addNew() {
		resetField();
		getOrderPembelian();

		$("#modalTitle").html("<i class='fa fa-plus fa-fw'></i> Tambah Pengembalian Pinjaman");

		$("#modalForm").modal({
			backdrop: "static"
		});
	}

	function edit(id) {

		resetField();
		$("body").off("change", "#txtIdPembelian", getOrder);

		$.post("controller/penerimaan_pembelian.php", {
			act: "getData",
			id: id
		}, function(data) {
			var dataSet = data.result[0];

			editDetail(dataSet.id_penerimaan_pembelian);
			$("#txtId").val(dataSet.id_penerimaan_pembelian);
			$("#txtTanggal").val(dataSet.tanggal);
			$("#txtIdLokasi").val(dataSet.id_lokasi).trigger("change");
			$("#txtKeterangan").val(dataSet.keterangan);

			// $("#txtIdPembelian").val(dataSet.id_order_pembelian);


			$("#modalTitle").html("<i class='fa fa-pencil fa-fw'></i> Edit Pengembalian Pinjaman");

			$("#modalForm").modal({
				backdrop: "static"
			});


			$("#txtIdPembelian").html("<option value='" + dataSet.id_order_pembelian + "' selected>[" + dataSet.kode_pembelian + "] " + dataSet.tanggal_kode_pembelian + "</option>");


		}, "json");


	}

	function del(id) {
		var konfirmasi = confirm("Apakah yakin akan menghapus data ini ?");

		if (konfirmasi) {
			$.post("controller/penerimaan_pembelian.php", {
				act: "del",
				id: id
			}, function(data) {
				if (data.status === true) {
					alert("Data berhasil di hapus");
					tabel.ajax.reload();
				} else {
					alert("Data gagal di hapus");
				}

			}, "json");
		}
	}

	function save() {
		var id = $("#txtId").val();
		var tanggal = $("#txtTanggal").val();
		var id_lokasi = $("#txtIdLokasi").val();
		var keterangan = $("#txtKeterangan").val();
		var id_pembelian = $("#txtIdPembelian").val();

		var id_barang = $(".id_barang").serializeArray();
		var jumlah_satuan_diterima = $(".jumlah_satuan_diterima").serializeArray();
		var jumlah_satuan2_diterima = $(".jumlah_satuan2_diterima").serializeArray();

		if (id_pembelian === "0" || tanggal === "" || id_lokasi === "0") {
			alert("pembelian, tanggal, lokasi tidak boleh kosong");
		} else {
			$.post("controller/penerimaan_pembelian.php", {
				act: "save",
				id: id,
				tanggal: tanggal,
				id_lokasi: id_lokasi,
				keterangan: keterangan,
				id_pembelian: id_pembelian,
				id_barang: id_barang,
				jumlah_satuan_diterima: jumlah_satuan_diterima,
				jumlah_satuan2_diterima: jumlah_satuan2_diterima
			}, function(data) {

				if (data.status === true) {
					alert("Data berhasil di simpan");
					$("#modalForm").modal("hide");
					tabel.ajax.reload();
				} else {
					alert("Data gagal di simpan");
				}

			}, "json");
		}

	}
</script>