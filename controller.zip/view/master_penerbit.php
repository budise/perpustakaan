<section class="content-header">
	<h1>
		Master Penerbit
		<small>Daftar Penerbit</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-th"></i> Dashboard</a></li>
		<li class="active">Master Penerbit</li>
	</ol>
</section>

<section class="content">
	<div class="box box-widget">
		<div class="box-header with-border">
			<h6 class="box-title">Master Penerbit</h6>
			<div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" onclick="addNew();"><i class="fa fa-plus fa-fw"></i> Tambah</button>
			</div>
		</div>

		<div class="box-body">
			<div class="table-responsive">
				<table class="table table-responsive table-bordered table-hover dataGrid" id="dataGrid">
					<thead>
						<tr>
							<th style="text-align:center">Kode</th>
							<th>Nama Penerbit</th>
							<th>Alamat</th>
							<th style="width:10%;text-align:center;"><i class="fa fa-gears fa-fw"></i></th>
						</tr>
					</thead>

					<tbody>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>

<div class="modal fade" id="modalForm">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times fa-fw"></i></button>
				<h5 class="modal-title" id="modalTitle"></h5>
			</div>

			<div class="modal-body">
				<input type="hidden" id="txtId" value="0">

				<div class="row">
					<div class="col-md-6">
						<label class="small-label">Kode Penerbit</label>
						<input type="text" class="form-control input-sm" id="txtKode">
					</div>

					<div class="col-md-6">
						<label class="small-label">Nama Penerbit</label>
						<input type="text" class="form-control input-sm" id="txtNama">
					</div>

				</div>

				<div class="row">
					<div class="col-md-12">
						<label class="small-label">Alamat</label>
						<textarea class="form-control" rows="3" style="resize: none;" id="txtAlamat"></textarea>
					</div>
				</div>

			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-sm" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Tutup</button>
				<button type="button" class="btn btn-success btn-sm" onclick="save();"><i class="fa fa-check fa-fw"></i> Simpan</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var tabel = $("#dataGrid").DataTable({
		processing: true,
		serverSide: true,
		paging: true,
		"ajax": {
			url: "controller/master_penerbit.php",
			type: "post",
			data: {
				act: "getAll",
			}
		},
		columns: [{
				className: "centerCol",
				data: "kode_penerbit"
			},
			{
				data: "nama_penerbit"
			},
			{
				data: "alamat_penerbit"
			},
			{
				data: null,
				className: "centerCol",
				sortable: false,
				defaultContent: "<button type='button' class='btn btn-info btn-xs btnEdit'><i class='fa fa-pencil fa-fw'></i></button> <button type='button' class='btn btn-danger btn-xs btnDel'><i class='fa fa-trash fa-fw'></i></button>"
			}
		]
	});

	$("#dataGrid tbody").on("click", ".btnEdit", function() {
		var data = tabel.row($(this).parents("tr")).data();
		edit(data[0]);
	});

	$("#dataGrid tbody").on("click", ".btnDel", function() {
		var data = tabel.row($(this).parents("tr")).data();
		del(data[0]);
	});

	function resetField() {
		$("#txtId").val("0");
		$("#modalForm .form-control").val("");
		$("#txtNama").focus();
	}

	function addNew() {
		resetField();

		$("#modalTitle").html("<i class='fa fa-plus fa-fw'></i> Tambah Baru");

		$("#modalForm").modal({
			backdrop: "static"
		});
	}

	function edit(id) {
		resetField();

		$.post("controller/master_penerbit.php", {
			act: "getData",
			id: id
		}, function(data) {
			var dataSet = data.result[0];

			$("#txtId").val(dataSet.id);
			$("#txtKode").val(dataSet.kode_penerbit);
			$("#txtNama").val(dataSet.nama_penerbit);
			$("#txtAlamat").val(dataSet.alamat_penerbit);

			$("#modalTitle").html("<i class='fa fa-pencil fa-fw'></i> Edit Data");

			$("#modalForm").modal({
				backdrop: "static"
			});

		}, "json");
	}

	function del(id) {
		var konfirmasi = confirm("Apakah yakin akan menghapus data ini ?");

		if (konfirmasi) {
			$.post("controller/master_penerbit.php", {
				act: "del",
				id: id
			}, function(data) {
				if (data.status === true) {
					tabel.ajax.reload();
				} else {
					alert("Data gagal di hapus");
				}

			}, "json");
		}
	}

	function save() {
		var id = $("#txtId").val();
		var kode = $("#txtkode").val();
		var nama = $("#txtNama").val();
		var alamat = $("#txtAlamat").val();

		$.post("controller/master_penerbit.php", {
			act: "save",
			id: id,
			nama: nama,
			kode: kode,
			alamat: alamat
		}, function(data) {

			if (data.status === true) {
				$("#modalForm").modal("hide");
				tabel.ajax.reload();
			} else {
				alert("Data gagal di simpan");
			}

		}, "json");

	}


	$("#btnFirst").click(function() {
		curPage = 1;

		refreshGrid();
	});

	$("#btnPrev").click(function() {
		if (curPage > 1) {
			curPage -= 1;
		}

		refreshGrid();
	});

	$("#btnNext").click(function() {
		if (curPage < maxPage) {
			curPage += 1;
		}

		refreshGrid();
	});

	$("#btnLast").click(function() {
		curPage = maxPage;

		refreshGrid();
	});
</script>