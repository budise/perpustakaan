<section class="content-header">
	<h1>
		Order Penjualan
		<small>Order peenjualan</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-th"></i> Dashboard</a></li>
		<li class="active">Order Penjualan</li>
	</ol>
</section>

<section class="content">
	<div class="box box-widget">
		<div class="box-header with-border">
			<h6 class="box-title">List Order Penjualan</h6>
			<div class="box-tools pull-right">				
				<button type="button" class="btn btn-box-tool" onclick="addNew();"><i class="fa fa-plus fa-fw"></i> Tambah</button>
			</div>
		</div>

		<div class="box-body">
			<div class="table-responsive">
				<table class="table table-bordered table-hover dataGrid" id="dataGrid">
					<thead>
						<tr>
							<th style="text-align:center">Kode</th>
							<th style="text-align:center">Tanggal</th>
							<th>Customer</th>
							<th style="text-align:center">Total</th>
							<th style="text-align: center;">Admin</th>
							<th style="width:10%;text-align:center;"><i class="fa fa-gears fa-fw"></i></th>
						</tr>
					</thead>

					<tbody>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>

<div class="modal fade" id="modalForm">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times fa-fw"></i></button>
				<h5 class="modal-title" id="modalTitle"></h5>
			</div>

			<div class="modal-body">
				<input type="hidden" id="act" name="act" value="save">
				<input type="hidden" id="txtId" name="id" value="0">

				<div class="row">
					<div class="col-md-4">
						<table class="small-table">
							<tr>
								<td style="vertical-align: middle;width: 25%;">Tanggal <span class="pull-right">:</span></td>
								<td><input type="text" class="form-control input-sm tanggal" id="txtTanggal"></td>
							</tr>
							<tr>
								<td style="vertical-align: middle;">Customer <span class="pull-right">:</span></td>
								<td><select class="form-control input-sm select2" id="txtIdCustomer" name="id_customer"></select></td>
							</tr>
						</table>
					</div>

					<div class="col-md-4 pull-right">
						<label class="small-label">Keterangan</label>
						<textarea class="form-control" rows="2" style="resize:none" id="txtKeterangan" name="keterangan"></textarea>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12">
						<button type="button" class="btn btn-primary btn-sm btn-flat bg-green" onclick="addDetail()"><i class="fa fa-plus fa-fw"></i> Tambah</button>

						<div class="table-responsive" style="margin-top: 1em;">
							<table class="table table-condensed table-bordered table-detail">
								<thead>
									<tr>
										<th>Barang</th>
										<th style="text-align: center;width:16%;">Jumlah</th>
										<th style="text-align: right;width:15%;">Harga</th>
										<th style="text-align: right;width:15%;">Subtotal</th>
										<th style="text-align: center;width:8%;"><i class="fa fa-times fa-fw"></i></th>
									</tr>
								</thead>

								<tbody id="detail-table">

								</tbody>

								<tfoot>
									<tr>
										<th colspan="3" style="text-align: right;vertical-align: middle;">Total</th>
										<th colspan="2">
											<input type="number" class="form-control input-sm" id="txtTotalHarga" name="total_harga" value="0" readonly>
										</th>
									</tr>
								</tfoot>
							</table>

							
						</div>
					</div>
				</div>


			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-sm" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Tutup</button>
				<button type="button" class="btn btn-success btn-sm" onclick="save();"><i class="fa fa-check fa-fw"></i> Simpan</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modalDetail">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times fa-fw"></i></button>
				<h5 class="modal-title"><i class="fa fa-file fa-fw"></i> Detail Order Penjualan</h5>
			</div>

			<div class="modal-body">
				<div class="row">
					<div class="col-md-8 col-sm-12 col-xs-12" style="margin-bottom: 10px;">
						<div class="table-responsive" style="margin-top: 5px;">
							<table class="small-table">
								<tr>
									<td style="width: 20%">Kode</td>
									<td>: <span id="lblKode"></span></td>
								</tr>
								<tr>
									<td>Tanggal</td>
									<td>: <span id="lblTanggal"></span></td>
								</tr>
								<tr>
									<td>Customer</td>
									<td>: <span id="lblNama"></span></td>
								</tr>
							</table>
						</div>
					</div>

					<div class="col-md-4 col-sm-12 col-xs-12">
						<label class="small-label">Keterangan</label><br>
						<span id="lblKeterangan"></span>
					</div>
				</div>
				<hr>
				<div class="row">
					<div class="col-md-12">
						<div class="table-responsive">
							<table class="table table-bordered table-detail">
								<thead>
									<tr>
										<th>Barang</th>
										<th style="width:16%;text-align: center;">Jumlah</th>
										<th style="width:16%;text-align: center;">Jumlah Terjual</th>
										<th style="width:15%;text-align: right">Harga</th>
										<th style="width:15%;text-align: right">Subtotal</th>
									</tr>
								</thead>

								<tbody id="detail-box">
								</tbody>
							</table>
						</div>
					</div>
				</div>
				
				
			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-sm" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Tutup</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">


	var tabel = $("#dataGrid").DataTable({
		processing: true,
		serverSide: true,
		paging: true,
		order: [
		[0, "desc"]
		],
		"ajax": {
			url: "controller/order_penjualan.php",
			type: "post",
			data: {
				act: "getAll",
			}
		},
		columns: [
		{
			className: "centerCol",
			width: "15%",
			data: "kode_order_penjualan",
			render: function(data){
				return "<a href='#' class='detail-data'>"+(data === null || data === '' ? '-' : data)+"</a>"
			}
		},
		{
			className: "centerCol",
			width: "12%",
			data: "tanggalString"
		},
		{data: "nama"},
		{
			className: "rightCol",
			width: "20%",
			data: "total_harga",
			render: function(data, type, row){
				return rupiah(data);
			}
		},
		{
			className: "centerCol",
			width: "10%",
			data: "admin",
			render: function(data, type, row){
				return "<label class='label label-primary'><i class='fa fa-user fa-fw'></i> "+data+"</label>";
			}
		},
		{
			data: null,
			className: "centerCol",
			sortable: false,
			defaultContent: "<button type='button' class='btn btn-info btn-xs btnEdit'><i class='fa fa-pencil fa-fw'></i></button> <button type='button' class='btn btn-danger btn-xs btnDel'><i class='fa fa-trash fa-fw'></i></button>"
		}
		]
	});

	$("#dataGrid tbody").on("click", ".btnEdit", function(){
		var data = tabel.row($(this).parents("tr")).data();
		edit(data[0]);
	});

	$("#dataGrid tbody").on("click", ".btnDel", function(){
		var data = tabel.row($(this).parents("tr")).data();
		del(data[0]);
	});

	$("#dataGrid tbody").on("click", ".detail-data", function(){
		var data = tabel.row($(this).parents("tr")).data();
		detail(data[0]);
	});



	function addDetail(){
		$.ajax({
			type: "post",
			url: "tabel-form/order_penjualan_detail.php",
			data: {
				act: "add"
			},
			success: function(data){
				$("#detail-table").append(data);
				$(".select2").select2();
			}
		});
	}

	function editDetail(id){
		$.ajax({
			type: "post",
			url: "tabel-form/order_penjualan_detail.php",
			data: {
				act: "edit",
				id: id
			},
			success: function(data){
				$("#detail-table").html(data);
				$(".select2").select2();
			}
		});
	}

	function viewDetail(id){
		$.ajax({
			type: "post",
			url: "tabel-form/order_penjualan_detail.php",
			data: {
				act: "detail",
				id: id
			},
			success: function(data){
				$("#detail-box").html(data);
			}
		});
	}

	$("#detail-table").on("click", ".removeDetail", function(){
		$(this).closest("tr").remove();

		hitungGrandTotal();
	});

	$("#detail-table").on("change", ".id_barang", function(){
		var id_barang = $(this).val();
		var rows = $(this).closest("tr");

		$.post("controller/master_barang_pokok.php",{
			act: "getData",
			id: id_barang
		}, function(data){
			var dataSet = data.result[0];

			rows.find("select[name='satuan']").val(dataSet.id_satuan);
			rows.find("input[name='harga']").val(dataSet.harga);
			rows.find("input[name='jumlah']").val("1");

			var jumlah = rows.find("input[name='jumlah']").val();
			var harga = rows.find("input[name='harga']").val();
			var subtotal = 0;

			subtotal = eval(jumlah)*eval(harga);

			rows.find("input[name='subtotal']").val(subtotal);

			hitungGrandTotal();

		}, "json");

	});


	$("#detail-table").on("change", ".harga", function(){
		var harga = isNaN($(this).val()) ? 0 : $(this).val();
		var jumlah = $(this).closest("tr").find("input[name='jumlah']").val();
		var total = 0;

		total = eval(jumlah)*eval(harga);

		$(this).closest("tr").find("input[name='subtotal']").val(total);

		hitungGrandTotal();
	});

	$("#detail-table").on("change", ".jumlah", function(){
		var jumlah = isNaN($(this).val()) ? 0 : $(this).val();
		var harga = $(this).closest("tr").find("input[name='harga']").val();
		var total = 0;

		total = eval(jumlah)*eval(harga);

		$(this).closest("tr").find("input[name='subtotal']").val(total);

		hitungGrandTotal();
	});

	function hitungGrandTotal(){
		var grandTotal = 0;

		$(".subtotal").each(function(i, val){
			var subTotal = isNaN($(this).val()) ? 0 : $(this).val();
			grandTotal = grandTotal + eval(subTotal);
		});

		$("#txtTotalHarga").val(grandTotal);
	}


	function detail(id){

		$.post("controller/order_penjualan.php",{
			act: "getData",
			id: id
		}, function(data){

			var dataSet = data.result[0];

			$("#lblKode").html(dataSet.kode_order_penjualan);
			$("#lblTanggal").html(dataSet.tanggal);
			$("#lblNama").html(dataSet.nama);
			$("#lblKeterangan").html(dataSet.keterangan);

			viewDetail(id);

		}, "json");

		$("#modalDetail").modal({
			backdrop: "static"
		});
	}

	function resetField(){
		$("#txtId").val("0");
		$("#modalForm .form-control").val("");
		$("#txtTanggal").focus();
		$("#txtIdCustomer").val("0").trigger("change");

		$("#detail-table").html("");

	}

	function getCustomer(){
		$.post("controller/order_penjualan.php",{
			act: "getCustomer"
		}, function(data){	
			var lst = "";

			lst += "<option value='0' selected>- Pilih Customer -</option>";

			$(data.result).each(function(i, val){
				lst += "<option value='"+val.id_customer+"'>["+val.kode_customer+"] "+val.nama+"</option>"
			});

			$("#txtIdCustomer").html(lst);

		}, "json");
	}

	getCustomer();

	function addNew(){
		resetField();

		$("#modalTitle").html("<i class='fa fa-plus fa-fw'></i> Tambah Order Penjualan");

		$("#modalForm").modal({
			backdrop: "static"
		});
	}

	function edit(id){
		resetField();

		$.post("controller/order_penjualan.php",{
			act: "getData",
			id: id
		}, function(data){
			var dataSet = data.result[0];

			$("#txtId").val(dataSet.id_order_penjualan);
			$("#txtTanggal").val(dataSet.tanggal);
			$("#txtIdCustomer").val(dataSet.id_customer).trigger("change");
			$("#txtTotalHarga").val(dataSet.total_harga);
			$("#txtKeterangan").val(dataSet.keterangan);

			editDetail(dataSet.id_order_penjualan);

			$("#modalTitle").html("<i class='fa fa-pencil fa-fw'></i> Edit Order Penjualan");

			$("#modalForm").modal({
				backdrop: "static"
			});

		}, "json");
	}

	function del(id){
		var konfirmasi = confirm("Apakah yakin akan menghapus data ini ?");

		if(konfirmasi){
			$.post("controller/order_penjualan.php",{
				act: "del",
				id: id
			}, function(data){
				if(data.status === true){
					alert("Data berhasil di hapus");
					tabel.ajax.reload();
				}else{
					alert("Data gagal di hapus");
				}

			}, "json");
		}
	}

	function save(){
		var id = $("#txtId").val();
		var tanggal = $("#txtTanggal").val();
		var id_customer = $("#txtIdCustomer").val();
		var total_harga = $("#txtTotalHarga").val();
		var keterangan = $("#txtKeterangan").val();

		var id_barang = $(".id_barang").serializeArray();
		var satuan = $(".satuan").serializeArray();
		var jumlah = $(".jumlah").serializeArray();
		var harga = $(".harga").serializeArray();
		var subtotal = $(".subtotal").serializeArray();

		$.post("controller/order_penjualan.php",{
			act: "save",
			id: id,
			tanggal: tanggal,
			id_customer: id_customer,
			total_harga: total_harga,
			keterangan: keterangan,
			id_barang: id_barang,
			jumlah: jumlah,
			satuan: satuan,
			harga: harga,
			subtotal: subtotal
		}, function(data){

			if(data.status === true){
				alert("Data berhasil di simpan");
				$("#modalForm").modal("hide");
				tabel.ajax.reload();
			}else{
				alert("Data gagal di simpan");
			}

		}, "json");

	}



</script>