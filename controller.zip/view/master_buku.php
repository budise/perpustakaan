<section class="content-header">
	<h1>
		Master buku
		<small>Daftar buku</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-th"></i> Dashboard</a></li>
		<li class="active">Master buku</li>
	</ol>
</section>

<section class="content">
	<div class="box box-widget">
		<div class="box-header with-border">
			<h6 class="box-title">Master buku</h6>
			<div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" onclick="addNew();"><i class="fa fa-plus fa-fw"></i> Tambah</button>
			</div>
		</div>

		<div class="box-body">
			<div class="table-responsive">
				<table class="table table-bordered table-hover dataGrid" id="dataGrid">
					<thead>
						<tr>
							<th style="text-align:center">Foto</th>
							<th style="text-align:center">Kode</th>
							<th>Nama Buku</th>
							<th style="text-align:left;">Penerbit</th>
							<th style="text-align:left;">Penulis</th>
							<th style="text-align:center">Stok</th>
							<th style="width:10%;text-align:center;"><i class="fa fa-gears fa-fw"></i></th>
						</tr>
					</thead>

					<tbody>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>

<form action="" method="post" id="form_data" enctype="multipart/form-data">
	<div class="modal fade" id="modalForm">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times fa-fw"></i></button>
					<h5 class="modal-title" id="modalTitle"></h5>
				</div>

				<div class="modal-body">
					<input type="hidden" id="act" name="act" value="save">
					<input type="hidden" id="txtId" name="id" value="0">

					<div class="row">
						<div class="col-md-6">
							<label class="small-label">Kode Buku</label>
							<input type="text" class="form-control input-sm" name="kode_buku" id="txtKode">
						</div>

						<div class="col-md-6">
							<label class="small-label">Judul Buku</label>
							<input class="form-control input-sm" name="judul" id="txtJudul">
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<label class="small-label">Penerbit</label>
							<input class="form-control input-sm" name="penerbit" id="txtPenerbit">
						</div>

						<div class="col-md-6">
							<label class="small-label">Penulis</label>
							<input class="form-control input-sm" name="penulis" id="txtPenulis">
						</div>
					</div>

					<div class="row">

						<div class="col-md-6">
							<label class="small-label">Stock</label>
							<input class="form-control input-sm" type="number" name="stock" id="txtStock">
						</div>

						<div class="col-md-6">
							<label class="small-label">Upload Foto</label>
							<input type="file" name="foto" id="foto" class="form-control input-sm">
						</div>
					</div>

				</div>

				<div class="modal-footer">
					<button type="button" class="btn btn-warning btn-sm" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Tutup</button>
					<button type="submit" class="btn btn-success btn-sm"><i class="fa fa-check fa-fw"></i> Simpan</button>
				</div>
			</div>
		</div>
	</div>
</form>

<div class="modal fade" id="modalDetail">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times fa-fw"></i></button>
				<h5 class="modal-title"><i class="fa fa-file fa-fw"></i> Detail Data</h5>
			</div>

			<div class="modal-body">
				<div class="row">
					<div class="col-md-4 col-sm-12 col-xs-12" style="margin-bottom: 10px;">
						<a href="" id="previewLink" target="_blank"><img src="" class="img-responsive img-thumbnail" style="height: 150px;width: 150px;" id="previewImage"></a>
					</div>

					<div class="col-md-8 col-sm-12 col-xs-12">
						<div class="table-responsive" style="margin-top: 5px;">
							<table class="table table-condensed">
								<tr>
									<td style="width: 30%">Kode</td>
									<td>: <span id="lblKode"></span></td>
								</tr>
								<tr>
									<td>Nama Buku</td>
									<td>: <span id="lblNama"></span></td>
								</tr>
								<tr>
									<td>Penerbit</td>
									<td>: <span id="lblPenerbit"></span></td>
								</tr>
								<tr>
									<td>Penulis</td>
									<td>: <span id="lblPenulis"></span></td>
								</tr>
								<tr>
									<td>Stock</td>
									<td>: <span id="lblStock"></span></td>
								</tr>
							</table>
						</div>
					</div>
				</div>


			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-sm" data-dismiss="modal"><i class="fa fa-times fa-fw"></i> Tutup</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var tabel = $("#dataGrid").DataTable({
		processing: true,
		serverSide: true,
		paging: true,
		order: [
			[0, "desc"]
		],
		"ajax": {
			url: "controller/master_buku.php",
			type: "post",
			data: {
				act: "getAll",
			}
		},
		columns: [{
				sortable: false,
				className: "centerCol",
				width: "12%",
				data: "gambar",
				render: function(data) {
					return "<img src='upload/" + (data === null || data === '' ? 'notfound.jpg' : data) + "' class='img-responsive img-thumb img-link' style='width:30px;height:30px;' />"
				}

			},
			{
				className: "centerCol",
				width: "15%",
				data: "kode_buku"
			},
			{
				data: "judul_buku"
			},
			{
				className: "centerCol",
				width: "12%",
				data: "namaPenerbit"
			},
			{
				className: "centerCol",
				width: "12%",
				data: "namaPenulis"
			},
			{
				className: "centerCol",
				width: "12%",
				data: "stock"
			}, {
				data: null,
				className: "centerCol",
				sortable: false,
				defaultContent: "<button type='button' class='btn btn-info btn-xs btnEdit'><i class='fa fa-pencil fa-fw'></i></button> <button type='button' class='btn btn-danger btn-xs btnDel'><i class='fa fa-trash fa-fw'></i></button>"
			}
		]
	});

	$("#dataGrid tbody").on("click", ".btnEdit", function() {
		var data = tabel.row($(this).parents("tr")).data();
		edit(data[0]);
	});

	$("#dataGrid tbody").on("click", ".btnDel", function() {
		var data = tabel.row($(this).parents("tr")).data();
		del(data[0]);
	});

	$("#dataGrid tbody").on("click", ".img-link", function() {
		var data = tabel.row($(this).parents("tr")).data();
		detail(data[0]);
	});

	function detail(id) {

		$.post("controller/master_buku.php", {
			act: "getData",
			id: id
		}, function(data) {

			var dataSet = data.result[0];

			$("#lblKode").html(dataSet.kode_buku);
			$("#lblNama").html(dataSet.judul_buku);
			$("#lblPenerbit").html(dataSet.namaPenerbit);
			$("#lblPenulis").html(dataSet.namaPenulis);
			$("#lblStock").html(dataSet.stock);
			// $("#lblSatuan").html(dataSet.strSatuan+", "+dataSet.strSatuan2);

			var dataImg = dataSet.gambar === null || dataSet.gambar === "" ? "notfound.jpg" : dataSet.gambar;

			$("#previewImage").attr("src", "upload/" + dataImg);
			$("#previewLink").attr("href", "upload/" + dataImg);

		}, "json");

		$("#modalDetail").modal({
			backdrop: "static"
		});
	}

	function resetField() {
		$("#txtId").val("0");
		$("#modalForm .form-control").val("");
		$("#txtNama").focus();
		$("#txtIdSatuan, #txtIdSatuan2").val("0");

	}


	$(document).ready(function() {
		$("#form_data").on("submit", function(e) {
			e.preventDefault();

			$.ajax({
				type: "post",
				url: "controller/master_buku.php",
				processData: false,
				contentType: false,
				cache: false,
				data: new FormData(this),
				dataType: "json",
				success: function(data) {

					switch (data.status) {
						case "invalid_extension":
							alert("Extensi file yang di izinkan hanya gambar!");
							break;
						case "error_upload":
							alert("Gagal mengupload file gambar!");
							break;
						case false:
							alert("Gagal menyimpan data!");
							break;
						case true:
							$("#modalForm").modal("hide");
							tabel.ajax.reload();
							break;
					}
				}
			});

		});
	});


	function getSatuan() {
		$.post("controller/master_buku.php", {
			act: "getSatuan"
		}, function(data) {
			var lst = "";

			lst += "<option value='0' selected>- Pilih Satuan -</option>";

			$(data.result).each(function(i, val) {
				lst += "<option value='" + val.id_satuan + "'>" + val.kode_satuan + "</option>"
			});

			$("#txtIdSatuan").html(lst);
			$("#txtIdSatuan2").html(lst);

		}, "json");
	}

	getSatuan();

	function addNew() {
		resetField();

		$("#modalTitle").html("<i class='fa fa-plus fa-fw'></i> Tambah Baru");

		$("#modalForm").modal({
			backdrop: "static"
		});
	}

	function edit(id) {
		resetField();

		$.post("controller/master_buku.php", {
			act: "getData",
			id: id
		}, function(data) {
			var dataSet = data.result[0];

			$("#txtId").val(dataSet.id);
			$("#txtKode").val(dataSet.kode_buku);
			$("#txtJudul").val(dataSet.judul_buku);
			$("#txtPenerbit").val(dataSet.namaPenerbit);
			$("#txtPenulis").val(dataSet.namaPenulis);
			$("#txtStock").val(dataSet.stock);

			$("#modalTitle").html("<i class='fa fa-pencil fa-fw'></i> Edit Data");

			$("#modalForm").modal({
				backdrop: "static"
			});

		}, "json");
	}

	function del(id) {
		var konfirmasi = confirm("Apakah yakin akan menghapus data ini ?");

		if (konfirmasi) {
			$.post("controller/master_buku.php", {
				act: "del",
				id: id
			}, function(data) {
				if (data.status === true) {
					alert("Data berhasil di hapus");
					tabel.ajax.reload();
				} else {
					alert("Data gagal di hapus");
				}

			}, "json");
		}
	}

	function save() {
		var id = $("#txtId").val();
		var nama = $("#txtNama").val();
		var telpon = $("#txtTelpon").val();
		var alamat = $("#txtAlamat").val();

		$.post("controller/master_buku.php", {
			act: "save",
			id: id,
			nama: nama,
			telpon: telpon,
			alamat: alamat
		}, function(data) {

			if (data.status === true) {
				alert("Data berhasil di simpan");
				$("#modalForm").modal("hide");
				tabel.ajax.reload();
			} else {
				alert("Data gagal di simpan");
			}

		}, "json");

	}
</script>