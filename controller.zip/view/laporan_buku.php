<?php
// require("sys/init.php");
$global_name = $_GET['pg'];
?>
<style type="text/css">
    .select2-container--default .select2-selection--single{
        height: 30px !important;
    }

    .select2-container--default .select2-selection--multiple{
        border-radius: 0px !important;
    }

    .select2-container--default .select2-selection--multiple .select2-selection__choice{
        background-color: #27AE60 !important;
    }

    .select2-container--default .select2-selection--multiple .select2-selection__choice__remove{
        color: #fff !important;
    }

    .datepicker{
        z-index: 1151 !important;
    }
</style>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <i class="fa fa-user"></i> Laporan Buku
        <small>Cetak Buku</small>
    </h1>
</section>

<!-- Main content -->
<section class="content container-fluid">
    <div class="box box-solid box-primary">
        <div class="box-header with-border">
            <h4 class="box-title">Filter Cetak Laporan Buku</h4>
        </div>

        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-primary ">
                        <div class="box-header with-border">
                            <h4 class="box-title"><i class="fa fa-filter"></i> Filter Kriteria</h4>
                        </div>

                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <button type="button" class="btn btn-success btn-sm" onclick="cetakSemuaData();"><i class="fa fa-print"></i> Cetak Semua Buku</button>
                                </div>
                                
                                <div class="col-md-9">
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-sort-amount-asc"></i> Urutkan Berdasarkan
                                            </span>
                                        <select class="form-control input-sm" id="txtSortBy">
                                            <option value="id">ID</option>
                                            <option value="nama">Nama</option>
                                            <option value="telpon">Telpon</option>
                                            <option value="kd_buku">Kode Buku</option>
                                        </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-sort-amount-asc"></i> Urutkan Asc / Desc
                                            </span>
                                        <select class="form-control input-sm" id="txtSortDir">
                                            <option value="desc">Descending</option>
                                            <option value="asc">Ascending</option>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- /.content -->

<script type="text/javascript">
    function cetakSemuaData() {
        var sortBy = $("#txtSortBy").val();
        var sortDir = $("#txtSortDir").val();
        
        window.open("controller/laporan_buku/cetakLaporan.php?act=cetakSemuaData&orderBy="+$("#txtSortBy").val()+"&orderDir="+$("#txtSortDir").val()+" ");
    }
</script>
