<?php
session_start();
$username = $_SESSION['id_user'];

require_once "../config/init.php";
require_once "../model/Crud_basic.php";

$cls = new Crud_basic($db);

//Group of Variable
$act      = isset($_POST['act']) ? $_POST['act'] : "";
$offset   = isset($_POST['start']) ? $_POST['start'] : 0;
$perPage  = isset($_POST['length']) ? $_POST['length'] : 10;
$draw     = isset($_POST['draw']) ? $_POST['draw'] : 1;
$sortBy   = isset($_POST['order'][0]['column']) ? $_POST['order'][0]['column'] : 0;
$sortDir  = isset($_POST['order'][0]['dir']) ? $_POST['order'][0]['dir'] : 'desc';
$criteria = isset($_POST['search']['value']) ? $_POST['search']['value'] : "1=1";

$fieldSort = array(
    "kode_order_pembelian",
    "tanggalString",
    "nama",
    "total_harga",
    "username",
);
$fieldSearch = array(
    "kode_order_pembelian",
    "tanggal",
    "nama",
    "total_harga",
    "username",
);
$stringSearch = "";

//Konfigurasi pencarian
if ($criteria !== "1=1") {
    $criteria = str_replace(" ", "%", $criteria);

    foreach ($fieldSearch as $val) {
        $stringSearch .= $val . " LIKE '%" . $criteria . "%' OR ";
    }

    $criteria = substr($stringSearch, 0, -4);

}

//Add, Update, Delete
$kode_prefix = "OP";

//Data Section
$id          = isset($_POST['id']) ? $_POST['id'] : "";
$tanggal     = isset($_POST['tanggal']) ? cleanInput($_POST['tanggal']) : "";
$id_supplier = isset($_POST['id_supplier']) ? cleanInput($_POST['id_supplier']) : "";
$total_harga = isset($_POST['total_harga']) ? cleanInput($_POST['total_harga']) : "";
$keterangan  = isset($_POST['keterangan']) ? cleanInput($_POST['keterangan']) : "";

//Detail order pembelian
$id_barang             = isset($_POST['id_barang']) ? $_POST['id_barang'] : 0;
$jumlah_satuan         = isset($_POST['jumlah_satuan']) ? $_POST['jumlah_satuan'] : 0;
$jumlah_satuan_dibeli  = isset($_POST['jumlah_satuan_dibeli']) ? $_POST['jumlah_satuan_dibeli'] : 0;
$jumlah_satuan2        = isset($_POST['jumlah_satuan2']) ? $_POST['jumlah_satuan2'] : 0;
$jumlah_satuan2_dibeli = isset($_POST['jumlah_satuan2_dibeli']) ? $_POST['jumlah_satuan2_dibeli'] : 0;
$harga                 = isset($_POST['harga']) ? $_POST['harga'] : 0;
$subtotal              = isset($_POST['subtotal']) ? $_POST['subtotal'] : 0;

$data_array = array(
    "tanggal"     => $tanggal,
    "id_supplier" => $id_supplier,
    "total_harga" => $total_harga,
    "keterangan"  => $keterangan,
    "id_user"     => $username,
);

if ($act == "getAll") {

    $query     = $cls->getArray("A.*, DATE_FORMAT(tanggal, '%d/%m/%Y') AS tanggalString, B.nama, C.username AS admin ", "order_pembelian A LEFT JOIN supplier B ON A.id_supplier = B.id_supplier LEFT JOIN admin C ON A.id_user = C.id_admin ", "($criteria) ORDER BY $fieldSort[$sortBy] $sortDir LIMIT $offset, $perPage");
    $get_count = $cls->getCount("A.*, B.nama, C.username ", "order_pembelian A LEFT JOIN supplier B ON A.id_supplier = B.id_supplier LEFT JOIN admin C ON A.id_user = C.id_admin ", "($criteria)");

    $ret['data']            = $query;
    $ret['recordsTotal']    = intval($get_count['total_record']);
    $ret['recordsFiltered'] = intval($get_count['total_record']);
    $ret['draw']            = intval($draw);

} elseif ($act == "getData") {

    $query = $cls->getArray("A.*, B.nama, C.username ", "order_pembelian A LEFT JOIN supplier B ON A.id_supplier = B.id_supplier LEFT JOIN admin C ON A.id_user = C.id_admin ", "id_order_pembelian=" . $id);

    $ret['result'] = $query;

} elseif ($act == "save") {

    if ($id == 0) {

        $query   = $cls->addNew("order_pembelian", $data_array);
        $getLast = $db->lastInsertId();

        $setKode = array(
            "kode_order_pembelian" => $kode_prefix . $getLast,
        );

        $cls->update("order_pembelian", $setKode, "id_order_pembelian=" . $getLast);

        foreach ($id_barang as $key => $val) {

            $arrayDetail = array(
                "id_order_pembelian"    => $getLast,
                "id_barang"             => $id_barang[$key]["value"],
                "jumlah_satuan"         => $jumlah_satuan[$key]["value"],
                "jumlah_satuan_dibeli"  => $jumlah_satuan_dibeli[$key]["value"],
                "jumlah_satuan2"        => $jumlah_satuan2[$key]["value"],
                "jumlah_satuan2_dibeli" => $jumlah_satuan2_dibeli[$key]["value"],
                "harga_beli"            => $harga[$key]["value"],
                "subtotal"              => $subtotal[$key]["value"],
            );

            $cls->addNew("detail_order_pembelian", $arrayDetail);
        }

    } else {

        $query           = $cls->update("order_pembelian", $data_array, "id_order_pembelian=" . $id);
        $del_prev_detail = $cls->del("detail_order_pembelian", "id_order_pembelian=" . $id);

        if ($del_prev_detail) {
            foreach ($id_barang as $key => $val) {

                $arrayDetail = array(
                    "id_order_pembelian"    => $id,
                    "id_barang"             => $id_barang[$key]["value"],
                    "jumlah_satuan"         => $jumlah_satuan[$key]["value"],
                    "jumlah_satuan_dibeli"  => $jumlah_satuan_dibeli[$key]["value"],
                    "jumlah_satuan2"        => $jumlah_satuan2[$key]["value"],
                    "jumlah_satuan2_dibeli" => $jumlah_satuan2_dibeli[$key]["value"],
                    "harga_beli"            => $harga[$key]["value"],
                    "subtotal"              => $subtotal[$key]["value"],
                );

                $cls->addNew("detail_order_pembelian", $arrayDetail);
            }
        }

    }

    if ($query) {
        $ret['status'] = true;
    } else {
        $ret['status'] = false;
    }

} elseif ($act == "del") {

    $query = $cls->del("order_pembelian", "id_order_pembelian=" . $id);

    if ($query) {
        $cls->del("detail_order_pembelian", "id_order_pembelian=" . $id);
        $ret['status'] = true;
    } else {
        $ret['status'] = false;
    }

} elseif ($act == "getSupplier") {

    $query = $cls->getArray("*", "supplier", "1=1");

    $ret['result'] = $query;
}

echo json_encode($ret);
