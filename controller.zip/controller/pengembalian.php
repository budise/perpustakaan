<?php
session_start();
$username = $_SESSION['id_user'];

require_once "../config/init.php";
require_once "../model/Crud_basic.php";

$cls = new Crud_basic($db);

//Group of Variable
$act      = isset($_POST['act']) ? $_POST['act'] : "";
$offset   = isset($_POST['start']) ? $_POST['start'] : 0;
$perPage  = isset($_POST['length']) ? $_POST['length'] : 10;
$draw     = isset($_POST['draw']) ? $_POST['draw'] : 1;
$sortBy   = isset($_POST['order'][0]['column']) ? $_POST['order'][0]['column'] : 0;
$sortDir  = isset($_POST['order'][0]['dir']) ? $_POST['order'][0]['dir'] : 'desc';
$criteria = isset($_POST['search']['value']) ? $_POST['search']['value'] : "1=1";

$fieldSort = array(
    "id_penerimaan_pembelian",
    "id_pembelian",
    "tanggalString",
    "keterangan_lokasi",
);
$fieldSearch = array(
    "kode_penerimaan_pembelian",
    "kode_pembelian",
    "A.tanggal",
    "keterangan_lokasi",
);
$stringSearch = "";

//Konfigurasi pencarian
if ($criteria !== "1=1") {
    $criteria = str_replace(" ", "%", $criteria);

    foreach ($fieldSearch as $val) {
        $stringSearch .= $val . " LIKE '%" . $criteria . "%' OR ";
    }

    $criteria = substr($stringSearch, 0, -4);

}

//Add, Update, Delete
$kode_prefix = "PPB";

//Data Section
$id           = isset($_POST['id']) ? $_POST['id'] : "";
$tanggal      = isset($_POST['tanggal']) ? cleanInput($_POST['tanggal']) : "";
$id_lokasi    = isset($_POST['id_lokasi']) ? intval($_POST['id_lokasi']) : "";
$keterangan   = isset($_POST['keterangan']) ? cleanInput($_POST['keterangan']) : "";
$id_pembelian = isset($_POST['id_pembelian']) ? intval($_POST['id_pembelian']) : 0;

//Detail pembelian
$id_barang               = isset($_POST['id_barang']) ? $_POST['id_barang'] : 0;
$jumlah_satuan_diterima  = isset($_POST['jumlah_satuan_diterima']) ? $_POST['jumlah_satuan_diterima'] : 0;
$jumlah_satuan2_diterima = isset($_POST['jumlah_satuan2_diterima']) ? $_POST['jumlah_satuan2_diterima'] : 0;

//Cek Jumlah
$state               = isset($_POST['state']) ? intval($_POST['state']) : 1;
$jumlah              = isset($_POST['jumlah']) ? intval($_POST['jumlah']) : 0;
$id_detail_pembelian = isset($_POST['id_detail_pembelian']) ? intval($_POST['id_detail_pembelian']) : 0;

$data_array = array(
    "id_pembelian" => $id_pembelian,
    "tanggal"      => $tanggal,
    "id_lokasi"    => $id_lokasi,
    "keterangan"   => $keterangan,
);

if ($act == "getAll") {

    $query     = $cls->getArray("A.*, DATE_FORMAT(A.tanggal, '%d/%m/%Y') AS tanggalString, B.keterangan_lokasi, C.kode_pembelian ", "penerimaan_pembelian A LEFT JOIN lokasi B ON A.id_lokasi = B.id_lokasi LEFT JOIN pembelian C ON A.id_pembelian = C.id_pembelian ", "($criteria) ORDER BY $fieldSort[$sortBy] $sortDir LIMIT $offset, $perPage");
    $get_count = $cls->getCount("A.*, B.keterangan_lokasi ", "penerimaan_pembelian A LEFT JOIN lokasi B ON A.id_lokasi = B.id_lokasi LEFT JOIN pembelian C ON A.id_pembelian = C.id_pembelian ", "($criteria)");

    $ret['data']            = $query;
    $ret['recordsTotal']    = intval($get_count['total_record']);
    $ret['recordsFiltered'] = intval($get_count['total_record']);
    $ret['draw']            = intval($draw);

} elseif ($act == "getData") {

    $query = $cls->getArray("A.*, B.keterangan_lokasi, C.kode_pembelian, DATE_FORMAT(C.tanggal, '%d/%m/%Y') AS tanggal_kode_pembelian ", "penerimaan_pembelian A LEFT JOIN lokasi B ON A.id_lokasi = B.id_lokasi LEFT JOIN pembelian C ON A.id_pembelian = C.id_pembelian ", "id_penerimaan_pembelian=" . $id);

    $ret['result'] = $query;

} elseif ($act == "save") {

    if ($id == 0) {

        $query   = $cls->addNew("penerimaan_pembelian", $data_array);
        $getLast = $db->lastInsertId();

        $setKode = array(
            "kode_penerimaan_pembelian" => $kode_prefix . $getLast,
        );

        $cls->update("penerimaan_pembelian", $setKode, "id_penerimaan_pembelian=" . $getLast);

        foreach ($id_barang as $key => $val) {

            //Insert detail
            $arrayDetail = array(
                "id_penerimaan_pembelian"   => $getLast,
                "id_barang"                 => $id_barang[$key]["value"],
                "jumlah_penerimaan_satuan"  => $jumlah_satuan_diterima[$key]["value"],
                "jumlah_penerimaan_satuan2" => $jumlah_satuan2_diterima[$key]["value"],
            );
            $cls->addNew("detail_penerimaan_pembelian", $arrayDetail);

            //Update Stok barang
            $get_prev_stok = $cls->getData("stok_1, stok_2","barang_pokok", "id_barang_pokok=".$id_barang[$key]["value"]);
            $prev_stok_1 = ($get_prev_stok['stok_1'] == null OR $get_prev_stok['stok_1'] == "") ? 0 : $get_prev_stok['stok_1'];
            $prev_stok_2 = ($get_prev_stok['stok_2'] == null OR $get_prev_stok['stok_2'] == "") ? 0 : $get_prev_stok['stok_2'];

            $new_stok_1 = $prev_stok_1 + $jumlah_satuan_diterima[$key]["value"];
            $new_stok_2 = $prev_stok_2 + $jumlah_satuan2_diterima[$key]["value"];

            $arrayDetailBarang = array(
                "stok_1" => $new_stok_1,
                "stok_2" => $new_stok_2,
            );
            $cls->update("barang_pokok", $arrayDetailBarang, "id_barang_pokok=" . $id_barang[$key]["value"]);

        }

    } else {

        $query           = $cls->update("penerimaan_pembelian", $data_array, "id_penerimaan_pembelian=" . $id);
        $del_prev_detail = $cls->del("detail_penerimaan_pembelian", "id_penerimaan_pembelian=" . $id);

        if ($del_prev_detail) {
            foreach ($id_barang as $key => $val) {

                //Insert Detail
                $arrayDetail = array(
                    "id_penerimaan_pembelian"   => $id,
                    "id_barang"                 => $id_barang[$key]["value"],
                    "jumlah_penerimaan_satuan"  => $jumlah_satuan_diterima[$key]["value"],
                    "jumlah_penerimaan_satuan2" => $jumlah_satuan2_diterima[$key]["value"],
                );
                $cls->addNew("detail_penerimaan_pembelian", $arrayDetail);
            }
        }

    }

    if ($query) {
        $ret['status'] = true;
    } else {
        $ret['status'] = false;
    }

} elseif ($act == "del") {

    $query = $cls->del("penerimaan_pembelian", "id_penerimaan_pembelian=" . $id);

    if ($query) {
        $cls->del("detail_penerimaan_pembelian", "id_penerimaan_pembelian=" . $id);
        $ret['status'] = true;
    } else {
        $ret['status'] = false;
    }

} elseif ($act == "getLokasi") {

    $query = $cls->getArray("*", "lokasi", "1=1");

    $ret['result'] = $query;
} elseif ($act == "getOrder") {

    $join_select = "ANY_VALUE(A.id_pembelian) AS id_pembelian, ANY_VALUE(A.kode_pembelian) AS kode_pembelian, ANY_VALUE(A.tanggal) AS tanggal, ";
    $join_select .= "ANY_VALUE((SELECT SUM(jumlah_satuan_diterima) FROM detail_pembelian WHERE id_pembelian = A.id_pembelian)) AS total_beli_1, ";
    $join_select .= "ANY_VALUE((SELECT SUM(jumlah_satuan2_diterima) FROM detail_pembelian WHERE id_pembelian = A.id_pembelian)) AS total_beli_2, ";
    $join_select .= "ANY_VALUE((SELECT SUM(DPP.jumlah_penerimaan_satuan) FROM detail_penerimaan_pembelian DPP LEFT JOIN penerimaan_pembelian PP ON DPP.id_penerimaan_pembelian = PP.id_penerimaan_pembelian WHERE PP.id_pembelian = A.id_pembelian)) AS total_penerimaan_1, ";
    $join_select .= "ANY_VALUE((SELECT SUM(DPP.jumlah_penerimaan_satuan2) FROM detail_penerimaan_pembelian DPP LEFT JOIN penerimaan_pembelian PP ON DPP.id_penerimaan_pembelian = PP.id_penerimaan_pembelian WHERE PP.id_pembelian = A.id_pembelian)) AS total_penerimaan_2, ";
    $join_select .= "ANY_VALUE(DATE_FORMAT(A.tanggal, '%d/%m/%Y')) AS tanggalString ";

    $join_table = "pembelian A LEFT JOIN penerimaan_pembelian B ON B.id_pembelian = A.id_pembelian ";

    $query = $cls->getArray($join_select, $join_table, "1=1 GROUP BY A.id_pembelian");

    $ret['result'] = $query;

} elseif ($act == "cekJumlah") {

    $join_select = "A.jumlah_satuan, A.jumlah_satuan2, A.id_detail_pembelian, A.id_pembelian, A.id_barang, A.jumlah_satuan_diterima, A.jumlah_satuan2_diterima, ";
    $join_select .= "(SELECT jumlah_penerimaan_satuan FROM detail_penerimaan_pembelian DPP "
        . "LEFT JOIN penerimaan_pembelian PP ON DPP.id_penerimaan_pembelian = PP.id_penerimaan_pembelian "
        . "WHERE PP.id_pembelian = A.id_pembelian AND DPP.id_barang = A.id_barang) AS jumlah_penerimaan_satuan, ";
    $join_select .= "(SELECT jumlah_penerimaan_satuan2 FROM detail_penerimaan_pembelian DPP "
        . "LEFT JOIN penerimaan_pembelian PP ON DPP.id_penerimaan_pembelian = PP.id_penerimaan_pembelian "
        . "WHERE PP.id_pembelian = A.id_pembelian AND DPP.id_barang = A.id_barang) AS jumlah_penerimaan_satuan2 ";

    $query = $cls->getData($join_select, "detail_pembelian A ", "A.id_detail_pembelian=" . $id_detail_pembelian);

    $jumlah_beli_1       = $query['jumlah_satuan_diterima'];
    $jumlah_beli_2       = $query['jumlah_satuan2_diterima'];
    $jumlah_penerimaan_1 = ($query['jumlah_penerimaan_satuan'] == null or $query['jumlah_penerimaan_satuan'] == "") ? 0 : $query['jumlah_penerimaan_satuan'];
    $jumlah_penerimaan_2 = ($query['jumlah_penerimaan_satuan2'] == null or $query['jumlah_penerimaan_satuan2'] == "") ? 0 : $query['jumlah_penerimaan_satuan2'];

    $jumlah_max = ($state === 1) ? ($jumlah_beli_1 - $jumlah_penerimaan_1) : ($jumlah_beli_2 - $jumlah_penerimaan_2);

    if ($jumlah > $jumlah_max) {
        $ret['status'] = "max";
        $ret['max']    = $jumlah_max;
    }

}

echo json_encode($ret);
