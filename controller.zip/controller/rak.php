<?php
require_once "../config/init.php";
require_once "../model/Crud_basic.php";

$cls = new Crud_basic($db);

//Group of Variable
$act      = isset($_POST['act']) ? $_POST['act'] : "";
$offset   = isset($_POST['start']) ? $_POST['start'] : 0;
$perPage  = isset($_POST['length']) ? $_POST['length'] : 10;
$draw     = isset($_POST['draw']) ? $_POST['draw'] : 1;
$sortBy   = isset($_POST['order'][0]['column']) ? $_POST['order'][0]['column'] : 0;
$sortDir  = isset($_POST['order'][0]['dir']) ? $_POST['order'][0]['dir'] : 'desc';
$criteria = isset($_POST['search']['value']) ? $_POST['search']['value'] : "1=1";

$fieldSort    = array("id_lokasi", "keterangan_lokasi", "alamat_lokasi", "jenis_lokasi");
$fieldSearch  = array("kode_lokasi", "keterangan_lokasi", "alamat_lokasi", "jenis_lokasi");
$stringSearch = "";

//Konfigurasi klausa pencarian
if ($criteria !== "1=1") {

    $criteria = str_replace(" ", "%", $criteria);

    foreach ($fieldSearch as $val) {
        $stringSearch .= $val . " LIKE '%" . $criteria . "%' OR ";
    }

    $criteria = substr($stringSearch, 0, -4);
}

//Add, Update, Delete
$kode_prefix = "KNV";

$id                = isset($_POST['id']) ? $_POST['id'] : "";
$keterangan_lokasi = isset($_POST['keterangan_lokasi']) ? cleanInput($_POST['keterangan_lokasi']) : "";
$alamat_lokasi     = isset($_POST['alamat_lokasi']) ? cleanInput($_POST['alamat_lokasi']) : "";
$jenis_lokasi      = isset($_POST['jenis_lokasi']) ? cleanInput($_POST['jenis_lokasi']) : "";

$data_array = array(
    "keterangan_lokasi" => $keterangan_lokasi,
    "alamat_lokasi"     => $alamat_lokasi,
    "jenis_lokasi"      => $jenis_lokasi,
);

if ($act == "getAll") {

    $query     = $cls->getArray("*", "lokasi", "($criteria) ORDER BY $fieldSort[$sortBy] $sortDir LIMIT $offset, $perPage");
    $get_count = $cls->getCount("*", "lokasi", "($criteria)");

    $ret['data']            = $query;
    $ret['recordsTotal']    = intval($get_count['total_record']);
    $ret['recordsFiltered'] = intval($get_count['total_record']);
    $ret['draw']            = intval($draw);

} elseif ($act == "getData") {

    $query = $cls->getArray("*", "lokasi", "id_lokasi=" . $id);

    $ret['result'] = $query;

} elseif ($act == "save") {

    if ($id == 0) {
        $query   = $cls->addNew("lokasi", $data_array);
        $getLast = $db->lastInsertId();

        $setKode = array(
            "kode_lokasi" => $kode_prefix . $getLast,
        );

        $cls->update("lokasi", $setKode, "id_lokasi=" . $getLast);

    } else {
        $query = $cls->update("lokasi", $data_array, "id_lokasi=" . $id);
    }

    if ($query) {
        $ret['status'] = true;
    } else {
        $ret['status'] = false;
    }

} elseif ($act == "del") {

    $query = $cls->del("lokasi", "id_lokasi=" . $id);

    if ($query) {
        $ret['status'] = true;
    } else {
        $ret['status'] = false;
    }

} elseif ($act == "get_jenis_lokasi") {

    $arr_lokasi = array();
    $get_lokasi = getEnum("lokasi", "jenis_lokasi");
    foreach ($get_lokasi as $lokasi) {
        array_push($arr_lokasi, $lokasi);
    }

    $ret['jenis_lokasi'] = $get_lokasi;

}

echo json_encode($ret);
