<?php
$DB_HOST = "localhost";
$DB_NAME = "perpustakaan";
$DB_USER = "root";
$DB_PASS = "";

