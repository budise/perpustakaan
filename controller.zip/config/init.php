<?php

ini_set("display_errors", "1");
require_once "db_conf.php";

function cleanInput($input)
{
    $str = htmlspecialchars(urldecode($input));
    $str = str_replace("'", "\'", $str);

    return $str;
}

function rupiah($str)
{
    return number_format($str, 0, ",", ".");
}

function formatingDates($str, $format_date)
{
    $tgl = date_create($str);
    return date_format($str, $format_date);
}

function checkParentMenu($search, $state)
{
    $menu_array = array(
        "master"    => array(
            "master_buku",
            "master_rak",
            "master_penulis",
            "master_penerbit",
            "master_anggota",
            "master_admin",
        ),
        "transaksi" => array(
            "peminjaman",
            "pengembalian",
            "Barang_masuk",
            "barang_keluar"
        ),
        "laporan" => array(
            "laporan_buku",
            "laporan_anggota",
            "laporan_peminjaman",
            "laporan_pengembalian",
            "laporan_barang_masuk",
            "laporan_barang_keluar"
        ),

    );

    if (in_array($search, $menu_array[$state])) {
        return "active";
    } else {
        return "";
    }
}

function checkMenu($cek, $cur)
{
    if ($cek == $cur) {
        return "class='active'";
    } else {
        return "";
    }
}

$db = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME", $DB_USER, $DB_PASS);

if (!$db) {
    die("Database connection error<br />" . print_r($db->errorInfo()));
}

//Function yang memiliki kebutuhan database
function getEnum($db, $tbl, $clm)
{
    $sql  = "SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='$tbl' AND COLUMN_NAME='$clm' ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchColumn();
    $result = str_replace("enum", "", $result);
    $result = str_replace("(", "", $result);
    $result = str_replace(")", "", $result);
    $result = str_replace("'", "", $result);
    $result = explode(",", $result);

    return $result;
}
