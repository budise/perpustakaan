<?php
require_once "../config/init.php";
require_once "../model/Crud_basic.php";

$cls = new Crud_basic($db);

$getBarang = $cls->getArray("*", "barang_pokok", "1=1");
$getSatuan = $cls->getArray("*", "satuan", "1=1");

$act = isset($_POST['act']) ? $_POST['act'] : "add";
$id  = isset($_POST['id']) ? intval($_POST['id']) : 1;

if ($act == "edit") {

    $getDetail = $cls->getArray("*", "detail_penerimaan_pembelian", "id_penerimaan_pembelian=" . $id);

    foreach ($getDetail as $rc) {

        echo "<tr>";
        echo "<td>";
        echo "<input type='hidden' class='id_barang' id='id_barang' name='id_barang' value='" . $rc['id_barang'] . "'>";
        foreach ($getBarang as $val) {
            if ($val['id_barang_pokok'] == $rc['id_barang']) {
                echo "[" . $val['kode_barang_pokok'] . "] " . $val['nama_barang_pokok'];
            }
        }
        echo "</td>";

        echo "<td style='width:16%' align='center'>";
        echo "<input style='text-align:center' type='number' class='form-control input-sm jumlah_satuan_diterima' id='jumlah_satuan_diterima' name='jumlah_satuan_diterima' value='" . $rc['jumlah_penerimaan_satuan'] . "' readonly>";
        echo "</td>";

        echo "<td style='width:16%' align='center'>";
        echo "<input style='text-align:center' type='number' class='form-control input-sm jumlah_satuan2_diterima' id='jumlah_satuan2_diterima' name='jumlah_satuan2_diterima' value='" . $rc['jumlah_penerimaan_satuan2'] . "' readonly>";
        echo "</td>";

        echo "</tr>";
    }

} elseif ($act == "detail") {

    $getDetail = $cls->getArray("*, "
        . "(SELECT nama_barang_pokok FROM barang_pokok WHERE id_barang_pokok = detail_penerimaan_pembelian.id_barang) AS nama_barang, "
        . "(SELECT kode_barang_pokok FROM barang_pokok WHERE id_barang_pokok = detail_penerimaan_pembelian.id_barang) AS kode_barang ", "detail_penerimaan_pembelian", "id_penerimaan_pembelian=" . $id);

    $total1 = 0;
    $total2 = 0;

    foreach ($getDetail as $val) {
        echo "<tr>";
        echo "<td>[" . $val['kode_barang'] . "] " . $val['nama_barang'] . "</td>";
        echo "<td align='center'>" . $val['jumlah_penerimaan_satuan'] . " </td>";
        echo "<td align='center'>" . $val['jumlah_penerimaan_satuan2'] . " </td>";
        echo "</tr>";

        $total1 = $total1 + $val['jumlah_penerimaan_satuan'];
        $total2 = $total2 + $val['jumlah_penerimaan_satuan2'];
    }

    echo "<tr class='info'>";
    echo "<td align='right'><b>Total</b></td>";
    echo "<td align='center'><b>" . $total1 . "</b></td>";
    echo "<td align='center'><b>" . $total2 . "</b></td>";
    echo "</tr>";

    echo $getDetail;
} elseif ($act == "get_order") {

    $join_select = "A.jumlah_satuan, A.jumlah_satuan2, A.id_detail_pembelian, A.id_pembelian, A.id_barang, A.jumlah_satuan_diterima, A.jumlah_satuan2_diterima, ";
    $join_select .= "(SELECT jumlah_penerimaan_satuan FROM detail_penerimaan_pembelian DPP "
        . "LEFT JOIN penerimaan_pembelian PP ON DPP.id_penerimaan_pembelian = PP.id_penerimaan_pembelian "
        . "WHERE PP.id_pembelian = A.id_pembelian AND DPP.id_barang = A.id_barang) AS jumlah_penerimaan_satuan, ";
    $join_select .= "(SELECT jumlah_penerimaan_satuan2 FROM detail_penerimaan_pembelian DPP "
        . "LEFT JOIN penerimaan_pembelian PP ON DPP.id_penerimaan_pembelian = PP.id_penerimaan_pembelian "
        . "WHERE PP.id_pembelian = A.id_pembelian AND DPP.id_barang = A.id_barang) AS jumlah_penerimaan_satuan2 ";

    $getDetail = $cls->getArray($join_select, "detail_pembelian A ", "A.id_pembelian=" . $id);

    foreach ($getDetail as $rc) {

        $jumlah_beli_1       = $rc['jumlah_satuan_diterima'];
        $jumlah_beli_2       = $rc['jumlah_satuan2_diterima'];
        $jumlah_penerimaan_1 = ($rc['jumlah_penerimaan_satuan'] == null OR $rc['jumlah_penerimaan_satuan'] == "") ? 0 : $rc['jumlah_penerimaan_satuan'];
        $jumlah_penerimaan_2 = ($rc['jumlah_penerimaan_satuan2'] == null OR $rc['jumlah_penerimaan_satuan2'] == "") ? 0 : $rc['jumlah_penerimaan_satuan2'];

        $jml1 = $jumlah_beli_1 - $jumlah_penerimaan_1;
        $jml2 = $jumlah_beli_2 - $jumlah_penerimaan_2;

        if ($jml1 !== 0 or $jumlah_penerimaan_1 < $jumlah_beli_1) {
            echo "<tr>";
            echo "<td>";
            echo "<input type='hidden' class='id_detail_pembelian' id='id_detail_pembelian' name='id_detail_pembelian' value='" . $rc['id_detail_pembelian'] . "'>";
            echo "<input type='hidden' class='id_barang' id='id_barang' name='id_barang' value='" . $rc['id_barang'] . "'>";
            foreach ($getBarang as $val) {
                if ($val['id_barang_pokok'] == $rc['id_barang']) {
                    echo "[" . $val['kode_barang_pokok'] . "] " . $val['nama_barang_pokok'];
                }
            }
            echo "</td>";

            echo "<td style='width:16%' align='center'>";
            echo "<div class='input-group'>";
            echo "<input type='number' style='text-align:right' class='form-control input-sm jumlah_satuan_diterima' id='jumlah_satuan_diterima' name='jumlah_satuan_diterima' value='" . $jml1. "'>";
            echo "<span class='input-group-addon'>";
            foreach ($getSatuan as $val) {
                if ($val['id_satuan'] == $rc['jumlah_satuan']) {
                    echo $val['kode_satuan'];
                }
            }
            echo "</span>";
            echo "</div>";
            echo "</td>";

            echo "<td style='width:16%' align='center'>";
            echo "<div class='input-group'>";
            echo "<input type='number' style='text-align:right' class='form-control input-sm jumlah_satuan2_diterima' id='jumlah_satuan2_diterima' name='jumlah_satuan2_diterima' value='" . $jml2 . "'>";
            echo "<span class='input-group-addon'>";
            foreach ($getSatuan as $val) {
                if ($val['id_satuan'] == $rc['jumlah_satuan2']) {
                    echo $val['kode_satuan'];
                }
            }
            echo "</span>";
            echo "</div>";
            echo "</td>";

            echo "</tr>";
        }

    }

}
