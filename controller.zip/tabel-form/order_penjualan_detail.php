<?php
require_once "../config/init.php";
require_once "../model/Crud_basic.php";

$cls = new Crud_basic($db);

$getBarang = $cls->getArray("*", "barang_jadi", "1=1");
$getSatuan = $cls->getArray("*", "satuan", "1=1");

$act = isset($_POST['act']) ? $_POST['act'] : "add";
$id  = isset($_POST['id']) ? intval($_POST['id']) : 1;

if ($act == "add") {

    echo "<tr>";

    echo "<td>";
    echo "<select class='form-control select2 id_barang' id='id_barang' name='id_barang'>";
    echo "<option value='0'>-Cari Barang -</option>";
    foreach ($getBarang as $val) {
        echo "<option value='" . $val['id_barang_jadi'] . "'>[" . $val['kode_barang_jadi'] . "] " . $val['nama_barang_jadi'] . "</option>";
    }
    echo "</select>";
    echo "</td>";

    echo "<td style='width:16%' align='center'>";
    echo "<div class='row'>";
    echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left: 14px;padding-right:14px'>";
    echo "<input type='number' class='form-control input-sm jumlah' id='jumlah' name='jumlah'>";
    echo "</div>";
    echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left:14px;padding-right:14px;'>";
    echo "<select class='form-control input-sm satuan' id='satuan' name='satuan'>";
    foreach ($getSatuan as $val) {
        echo "<option value='" . $val['id_satuan'] . "'>" . $val['kode_satuan'] . "</option>";
    }
    echo "</select>";
    echo "</div>";
    echo "</div>";
    echo "</td>";

    echo "<td style='width:15%' align='right'>";
    echo "<input type='number' class='form-control input-sm harga' id='harga' name='harga'>";
    echo "</td>";

    echo "<td style='width:15%' align='right'>";
    echo "<input type='number' class='form-control input-sm subtotal' id='subtotal' name='subtotal' readonly>";
    echo "</td>";

    echo "<td style='width:8%' align='center'>";
    echo "<button type='button' class='btn btn-danger btn-sm btn-flat bg-red removeDetail'><i class='fa fa-times fa-fw'></i></button>";
    echo "</td>";

    echo "</tr>";

} elseif ($act == "edit") {

    $getDetail = $cls->getArray("*", "detail_order_penjualan", "id_order_penjualan=" . $id);

    foreach ($getDetail as $rc) {

        echo "<tr>";
        echo "<td>";
        echo "<select class='form-control select2 id_barang' id='id_barang' name='id_barang'>";
        echo "<option value='0'>-Cari Barang -</option>";
        foreach ($getBarang as $val) {
            echo "<option value='" . $val['id_barang_jadi'] . "' ".($val['id_barang_jadi'] == $rc['id_barang'] ? "selected" : "").">";
            echo "[" . $val['kode_barang_jadi'] . "] " . $val['nama_barang_jadi'];
            echo "</option>";
        }
        echo "</select>";
        echo "</td>";

        echo "<td style='width:16%' align='center'>";
        echo "<div class='row'>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left: 14px;padding-right:14px'>";
        echo "<input type='number' class='form-control input-sm jumlah' id='jumlah' name='jumlah' value='".$rc['jumlah']."'>";
        echo "</div>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left:14px;padding-right:14px;'>";
        echo "<select class='form-control input-sm satuan' id='satuan' name='satuan'>";
        foreach ($getSatuan as $val) {
            echo "<option value='" . $val['id_satuan'] . "' " . ($val['id_satuan'] == $rc['satuan'] ? "selected" : "") . ">" . $val['kode_satuan'] . "</option>";
        }
        echo "</select>";
        echo "</div>";
        echo "</div>";
        echo "</td>";


        echo "<td style='width:15%' align='right'>";
        echo "<input type='number' class='form-control input-sm harga' id='harga' name='harga' value='" . $rc['harga_jual'] . "'>";
        echo "</td>";

        echo "<td style='width:15%' align='right'>";
        echo "<input type='number' class='form-control input-sm subtotal' id='subtotal' name='subtotal' value='" . $rc['subtotal'] . "' readonly>";
        echo "</td>";

        echo "<td style='width:8%' align='center'>";
        echo "<button type='button' class='btn btn-danger btn-sm btn-flat bg-red removeDetail'><i class='fa fa-times fa-fw'></i></button>";
        echo "</td>";


        echo "</tr>";
    }

} elseif ($act == "detail") {


    $getDetail = $cls->getArray("*, "
        . "(SELECT nama_barang_jadi FROM barang_jadi WHERE id_barang_jadi = detail_order_penjualan.id_barang) AS nama_barang, "
        . "(SELECT kode_barang_jadi FROM barang_jadi WHERE id_barang_jadi = detail_order_penjualan.id_barang) AS kode_barang, "
        . "(SELECT kode_satuan FROM satuan WHERE id_satuan = detail_order_penjualan.satuan) AS satuan ", "detail_order_penjualan", "id_order_penjualan=" . $id);

    $total = 0;

    foreach ($getDetail as $val) {
        echo "<tr>";
        echo "<td>[" . $val['kode_barang'] . "] " . $val['nama_barang'] . "</td>";
        echo "<td align='center'>" . $val['jumlah'] . " " . $val['satuan'] . "</td>";
        echo "<td align='center'>" . $val['jumlah'] . " " . $val['satuan'] . "</td>";
        echo "<td align='right'>" . rupiah($val['harga_jual']) . "</td>";
        echo "<td align='right'>" . rupiah($val['subtotal']) . "</td>";
        echo "</tr>";

        $total = $total + $val['subtotal'];
    }

    echo "<tr class='info'>";
    echo "<td colspan='4' align='right'><b>Total</b></td>";
    echo "<td align='right'><b>" . rupiah($total) . "</b></td>";
    echo "</tr>";
}
