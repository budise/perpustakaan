<?php
require_once "../config/init.php";
require_once "../model/Crud_basic.php";

$cls = new Crud_basic($db);

$getBarang = $cls->getArray("*", "barang_pokok", "1=1");
$getSatuan = $cls->getArray("*", "satuan", "1=1");

$act = isset($_POST['act']) ? $_POST['act'] : "add";
$id  = isset($_POST['id']) ? intval($_POST['id']) : 1;

if ($act == "add") {

    echo "<tr>";

    echo "<td>";
    echo "<select class='form-control select2 id_barang' id='id_barang' name='id_barang'>";
    echo "<option value='0'>-Cari Barang -</option>";
    foreach ($getBarang as $val) {
        echo "<option value='" . $val['id_barang_pokok'] . "'>[" . $val['kode_barang_pokok'] . "] " . $val['nama_barang_pokok'] . "</option>";
    }
    echo "</select>";
    echo "</td>";

    echo "<td style='width:16%' align='center'>";
    echo "<div class='row'>";
    echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left: 14px;padding-right:14px'>";
    echo "<input type='number' class='form-control input-sm jumlah_satuan_diterima' id='jumlah_satuan_diterima' name='jumlah_satuan_diterima'>";
    echo "</div>";
    echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left:14px;padding-right:14px;'>";
    echo "<select class='form-control input-sm jumlah_satuan' id='jumlah_satuan' name='jumlah_satuan'>";
    foreach ($getSatuan as $val) {
        echo "<option value='" . $val['id_satuan'] . "'>" . $val['kode_satuan'] . "</option>";
    }
    echo "</select>";
    echo "</div>";
    echo "</div>";
    echo "</td>";

    echo "<td style='width:16%' align='center'>";
    echo "<div class='row'>";
    echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left: 14px;padding-right:14px'>";
    echo "<input type='number' class='form-control input-sm jumlah_satuan2_diterima' id='jumlah_satuan2_diterima' name='jumlah_satuan2_diterima'>";
    echo "</div>";
    echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left:14px;padding-right:14px;'>";
    echo "<select class='form-control input-sm jumlah_satuan2' id='jumlah_satuan2' name='jumlah_satuan2'>";
    foreach ($getSatuan as $val) {
        echo "<option value='" . $val['id_satuan'] . "'>" . $val['kode_satuan'] . "</option>";
    }
    echo "</select>";
    echo "</div>";
    echo "</div>";
    echo "</td>";

    echo "<td style='width:15%' align='right'>";
    echo "<input type='number' class='form-control input-sm harga' id='harga' name='harga'>";
    echo "</td>";

    echo "<td style='width:15%' align='right'>";
    echo "<input type='number' class='form-control input-sm subtotal' id='subtotal' name='subtotal' readonly>";
    echo "</td>";

    echo "<td style='width:8%' align='center'>";
    echo "<button type='button' class='btn btn-danger btn-sm btn-flat bg-red removeDetail'><i class='fa fa-times fa-fw'></i></button>";
    echo "</td>";

    echo "</tr>";

} elseif ($act == "edit") {

    $getDetail = $cls->getArray("*", "detail_pembelian", "id_pembelian=" . $id);

    foreach ($getDetail as $rc) {

        echo "<tr>";
        echo "<td>";
        echo "<select class='form-control select2 id_barang' id='id_barang' name='id_barang'>";
        echo "<option value='0'>-Cari Barang -</option>";
        foreach ($getBarang as $val) {
            echo "<option value='" . $val['id_barang_pokok'] . "' " . ($val['id_barang_pokok'] == $rc['id_barang'] ? "selected" : "") . ">";
            echo "[" . $val['kode_barang_pokok'] . "] " . $val['nama_barang_pokok'];
            echo "</option>";
        }
        echo "</select>";
        echo "</td>";

        echo "<td style='width:16%' align='center'>";
        echo "<div class='row'>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left: 14px;padding-right:14px'>";
        echo "<input type='number' class='form-control input-sm jumlah_satuan_diterima' id='jumlah_satuan_diterima' name='jumlah_satuan_diterima' value='" . $rc['jumlah_satuan_diterima'] . "'>";
        echo "</div>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left:14px;padding-right:14px;'>";
        echo "<select class='form-control input-sm jumlah_satuan' id='jumlah_satuan' name='jumlah_satuan'>";
        foreach ($getSatuan as $val) {
            echo "<option value='" . $val['id_satuan'] . "' " . ($val['id_satuan'] == $rc['jumlah_satuan'] ? "selected" : "") . ">" . $val['kode_satuan'] . "</option>";
        }
        echo "</select>";
        echo "</div>";
        echo "</div>";
        echo "</td>";

        echo "<td style='width:16%' align='center'>";
        echo "<div class='row'>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left: 14px;padding-right:14px'>";
        echo "<input type='number' class='form-control input-sm jumlah_satuan2_diterima' id='jumlah_satuan2_diterima' name='jumlah_satuan2_diterima' value='" . $rc['jumlah_satuan2_diterima'] . "'>";
        echo "</div>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left:14px;padding-right:14px;'>";
        echo "<select class='form-control input-sm jumlah_satuan2' id='jumlah_satuan2' name='jumlah_satuan2'>";
        foreach ($getSatuan as $val) {
            echo "<option value='" . $val['id_satuan'] . "' " . ($val['id_satuan'] == $rc['jumlah_satuan2'] ? "selected" : "") . ">" . $val['kode_satuan'] . "</option>";
        }
        echo "</select>";
        echo "</div>";
        echo "</div>";
        echo "</td>";

        echo "<td style='width:15%' align='right'>";
        echo "<input type='number' class='form-control input-sm harga' id='harga' name='harga' value='" . $rc['harga_beli'] . "'>";
        echo "</td>";

        echo "<td style='width:15%' align='right'>";
        echo "<input type='number' class='form-control input-sm subtotal' id='subtotal' name='subtotal' value='" . $rc['subtotal'] . "' readonly>";
        echo "</td>";

        echo "<td style='width:8%' align='center'>";
        echo "<button type='button' class='btn btn-danger btn-sm btn-flat bg-red removeDetail'><i class='fa fa-times fa-fw'></i></button>";
        echo "</td>";

        echo "</tr>";
    }

} elseif ($act == "detail") {

    $getDetail = $cls->getArray("*, "
        . "(SELECT nama_barang_pokok FROM barang_pokok WHERE id_barang_pokok = detail_pembelian.id_barang) AS nama_barang, "
        . "(SELECT kode_barang_pokok FROM barang_pokok WHERE id_barang_pokok = detail_pembelian.id_barang) AS kode_barang, "
        . "(SELECT kode_satuan FROM satuan WHERE id_satuan = detail_pembelian.jumlah_satuan) AS satuan, "
        . "(SELECT kode_satuan FROM satuan WHERE id_satuan = detail_pembelian.jumlah_satuan2) AS satuan2 ", "detail_pembelian", "id_pembelian=" . $id);

    $total = 0;

    foreach ($getDetail as $val) {
        echo "<tr>";
        echo "<td>[" . $val['kode_barang'] . "] " . $val['nama_barang'] . "</td>";
        echo "<td align='center'>" . $val['jumlah_satuan_diterima'] . " " . $val['satuan'] . "</td>";
        echo "<td align='center'>" . $val['jumlah_satuan2_diterima'] . " " . $val['satuan2'] . "</td>";
        echo "<td align='right'>" . rupiah($val['harga_beli']) . "</td>";
        echo "<td align='right'>" . rupiah($val['subtotal']) . "</td>";
        echo "</tr>";

        $total = $total + $val['subtotal'];
    }

    echo "<tr class='info'>";
    echo "<td colspan='4' align='right'><b>Total</b></td>";
    echo "<td align='right'><b>" . rupiah($total) . "</b></td>";
    echo "</tr>";
} elseif ($act == "get_order") {

    $getDetail = $cls->getArray("*", "detail_order_pembelian", "id_order_pembelian=" . $id);

    foreach ($getDetail as $rc) {

        echo "<tr>";
        echo "<td>";
        echo "<select class='form-control select2 id_barang' id='id_barang' name='id_barang'>";
        echo "<option value='0'>-Cari Barang -</option>";
        foreach ($getBarang as $val) {
            echo "<option value='" . $val['id_barang_pokok'] . "' " . ($val['id_barang_pokok'] == $rc['id_barang'] ? "selected" : "") . ">";
            echo "[" . $val['kode_barang_pokok'] . "] " . $val['nama_barang_pokok'];
            echo "</option>";
        }
        echo "</select>";
        echo "</td>";

        echo "<td style='width:16%' align='center'>";
        echo "<div class='row'>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left: 14px;padding-right:14px'>";
        echo "<input type='number' class='form-control input-sm jumlah_satuan_diterima' id='jumlah_satuan_diterima' name='jumlah_satuan_diterima' value='" . $rc['jumlah_satuan_dibeli'] . "'>";
        echo "</div>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left:14px;padding-right:14px;'>";
        echo "<select class='form-control input-sm jumlah_satuan' id='jumlah_satuan' name='jumlah_satuan'>";
        foreach ($getSatuan as $val) {
            echo "<option value='" . $val['id_satuan'] . "' " . ($val['id_satuan'] == $rc['jumlah_satuan'] ? "selected" : "") . ">" . $val['kode_satuan'] . "</option>";
        }
        echo "</select>";
        echo "</div>";
        echo "</div>";
        echo "</td>";

        echo "<td style='width:16%' align='center'>";
        echo "<div class='row'>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left: 14px;padding-right:14px'>";
        echo "<input type='number' class='form-control input-sm jumlah_satuan2_diterima' id='jumlah_satuan2_diterima' name='jumlah_satuan2_diterima' value='" . $rc['jumlah_satuan2_dibeli'] . "'>";
        echo "</div>";
        echo "<div class='col-md-6 col-sm-6 col-xs-6' style='padding-left:14px;padding-right:14px;'>";
        echo "<select class='form-control input-sm jumlah_satuan2' id='jumlah_satuan2' name='jumlah_satuan2'>";
        foreach ($getSatuan as $val) {
            echo "<option value='" . $val['id_satuan'] . "' " . ($val['id_satuan'] == $rc['jumlah_satuan2'] ? "selected" : "") . ">" . $val['kode_satuan'] . "</option>";
        }
        echo "</select>";
        echo "</div>";
        echo "</div>";
        echo "</td>";

        echo "<td style='width:15%' align='right'>";
        echo "<input type='number' class='form-control input-sm harga' id='harga' name='harga' value='" . $rc['harga_beli'] . "'>";
        echo "</td>";

        echo "<td style='width:15%' align='right'>";
        echo "<input type='number' class='form-control input-sm subtotal' id='subtotal' name='subtotal' value='" . $rc['subtotal'] . "' readonly>";
        echo "</td>";

        echo "<td style='width:8%' align='center'>";
        echo "<button type='button' class='btn btn-danger btn-sm btn-flat bg-red removeDetail'><i class='fa fa-times fa-fw'></i></button>";
        echo "</td>";

        echo "</tr>";
    }

}
